import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import OperatorPage from '@/pages/OperatorPage';
import PresenterPage from '@/pages/PresenterPage';
import LoginPage from '@/pages/LoginPage';
import SignUpPage from '@/pages/SignUpPage'; // Importar a nova página de cadastro
import { default as WrappedDashboardPage } from '@/pages/DashboardPage';
import { CommunityPage as WrappedCommunityPage } from '@/pages/CommunityPage';
import { AuthProvider, useAuth } from '@/contexts/AuthContext';
import { Loader2 } from 'lucide-react'; 

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useAuth();
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-900 flex flex-col items-center justify-center text-white">
        <Loader2 className="w-16 h-16 animate-spin text-sky-400 mb-4" />
        <p className="text-2xl tracking-wider">Autenticando...</p>
      </div>
    );
  }
  return user ? children : <Navigate to="/login" replace />;
};

function AppContent() {
  return (
    <>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignUpPage />} /> {/* Rota para a página de cadastro */}
        <Route 
          path="/" 
          element={
            <ProtectedRoute>
              <WrappedDashboardPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/community" 
          element={
            <ProtectedRoute>
              <WrappedCommunityPage />
            </ProtectedRoute>
          } 
        />
        <Route 
          path="/project/:projectId/operator" 
          element={
            <ProtectedRoute>
              <OperatorPage />
            </ProtectedRoute>
          } 
        />
         <Route 
          path="/project/:projectId/presenter" 
          element={
            <ProtectedRoute>
              <PresenterPage />
            </ProtectedRoute>
          } 
        />
        <Route path="/operator" element={<Navigate to="/" replace />} />
        <Route path="/presenter" element={<Navigate to="/" replace />} />
        
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <Toaster />
    </>
  );
}

function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}

export default App;