
import { v4 as uuidv4 } from 'uuid';

export const mockRundown = {
  id: 'rundown-01',
  title: 'Lançamento de Produto Tech',
  eventDate: '17 de Junho, 2025',
  items: [ 
    {
      id: uuidv4(),
      type: 'MUSIC',
      title: 'Abertura Musical',
      description: 'DJ Sonic nos toca-discos para aquecer o público.',
      duration: 180,
    },
    {
      id: uuidv4(),
      type: 'SPEAKER',
      title: 'Boas-vindas e Introdução',
      description: 'Ana Silva, CEO, compartilha a visão e agenda do evento.',
      duration: 300,
    },
    {
      id: uuidv4(),
      type: 'VT',
      title: 'Vídeo: A Jornada da Inovação',
      description: 'Um olhar inspirador sobre o processo de criação do novo produto.',
      duration: 240,
    },
    {
      id: uuidv4(),
      type: 'SPEAKER',
      title: 'Demonstração do Produto',
      description: 'Carlos Mendes, Diretor de Produto, revela as funcionalidades.',
      duration: 900,
    },
    {
      id: uuidv4(),
      type: 'PANEL',
      title: 'Painel de Discussão: O Futuro da Tecnologia',
      description: 'Mediador: Bia Costa com especialistas do setor.',
      duration: 1200,
    },
    {
      id: uuidv4(),
      type: 'SPEAKER',
      title: 'Sessão de Perguntas e Respostas',
      description: 'Oportunidade para o público interagir com os palestrantes.',
      duration: 600,
    },
    {
      id: uuidv4(),
      type: 'VT',
      title: 'Vídeo de Encerramento',
      description: 'Mensagem final e agradecimentos.',
      duration: 120,
    },
    {
      id: uuidv4(),
      type: 'MUSIC',
      title: 'Música de Encerramento',
      description: 'DJ Sonic retorna para fechar o evento com chave de ouro.',
      duration: 300,
    },
  ],
};

export const communityTemplates = [
  {
    id: uuidv4(),
    name: 'Modelo: Conferência de Tecnologia (1 Dia)',
    description: 'Estrutura completa para um dia de palestras, painéis e keynotes.',
    category: 'Conferência',
    icon: 'Presentation', 
    author: 'AdminRID',
    sharedAt: new Date('2025-06-10T10:00:00Z').toISOString(),
    downloads: 125,
    structure: { 
      folders: [
        { title: 'Manhã - Keynotes', events: [{title: 'Abertura', duration: 300}, {title: 'Keynote Principal', duration: 1800}]},
        { title: 'Tarde - Trilhas Técnicas', events: [{title: 'Trilha A - Palestra 1', duration: 1200}, {title: 'Trilha B - Palestra 1', duration: 1200}]},
      ]
    }
  },
  {
    id: uuidv4(),
    name: 'Template: Live Musical Acústica',
    description: 'Roteiro ideal para uma apresentação musical intimista online.',
    category: 'Show Ao Vivo',
    icon: 'Music2',
    author: 'StudioFlow',
    sharedAt: new Date('2025-06-12T14:30:00Z').toISOString(),
    downloads: 88,
     structure: { 
      folders: [
        { title: 'Bloco 1', events: [{title: 'Música 1', duration: 240}, {title: 'Interação', duration: 120}, {title: 'Música 2', duration: 200}]},
        { title: 'Bloco 2', events: [{title: 'Música 3 (Cover)', duration: 180}, {title: 'Agradecimentos', duration: 60}]},
      ]
    }
  },
  {
    id: uuidv4(),
    name: 'Podcast Semanal: Entrevista Tech',
    description: 'Estrutura base para episódios de podcast com entrevistas.',
    category: 'Podcast',
    icon: 'Mic',
    author: 'PodcastPros',
    sharedAt: new Date('2025-06-15T09:00:00Z').toISOString(),
    downloads: 210,
    structure: { 
      folders: [
        { title: 'Intro', events: [{title: 'Vinheta de Abertura', duration: 30}, {title: 'Apresentação do Convidado', duration: 120}]},
        { title: 'Entrevista Bloco 1', events: [{title: 'Pergunta Chave 1', duration: 600}, {title: 'Pergunta Chave 2', duration: 600}]},
        { title: 'Encerramento', events: [{title: 'Considerações Finais', duration: 180}, {title: 'Vinheta de Saída', duration: 30}]},
      ]
    }
  }
];
