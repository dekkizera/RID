import { useState, useEffect, useCallback, useRef } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabaseClient';
import { defaultColors, defaultEventIcons } from '@/lib/constants';
import { 
  advanceToNextItemLogic, 
  playPauseLogic, 
  resetRundownLogic, 
  selectItemLogic,
  saveFolderLogic,
  deleteFolderLogic,
  saveEventLogic,
  deleteEventLogic
} from '@/lib/rundownLogic';
import { toast as toastEmitter } from '@/components/ui/use-toast';
import { useRundownTimer } from '@/hooks/useRundownTimer';
import { useSupabaseRundownSync } from '@/hooks/useSupabaseRundownSync';
import { loadAudioFile } from '@/lib/audioUtils';


const getInitialLocalRundownState = (projectId, title = 'Novo Rundown') => {
  return {
    rundown: {
      id: projectId,
      title: title,
      eventDate: new Date().toLocaleDateString(),
      folders: [{ id: uuidv4(), title: 'Nova Pasta', color: defaultColors[0], events: [] }],
    },
    currentFolderIndex: 0,
    currentItemIndex: 0,
    elapsedTime: 0,
    isRunning: false,
    projectId: projectId,
    last_updated_by_operator_at: new Date().toISOString(),
  };
};

export const useRundownState = () => {
  const { projectId } = useParams();
  const { user } = useAuth();
  const [state, setInternalState] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const notificationSoundRef = useRef(null);
  const tenSecondWarningPlayedRef = useRef(false);
  const isOperatorTab = useRef(false);
  const isUnmountedRefHook = useRef(false);

  useEffect(() => {
    isUnmountedRefHook.current = false;
    if(typeof window !== 'undefined' && window.location.pathname.includes('/operator')) {
      isOperatorTab.current = true;
    }
    loadAudioFile('/notification.mp3').then(buffer => {
      if (!isUnmountedRefHook.current) {
        notificationSoundRef.current = buffer;
      }
    });
    return () => { 
      isUnmountedRefHook.current = true; 
    };
  }, []);

  const { saveStateToSupabase } = useSupabaseRundownSync(
    projectId, 
    user, 
    setInternalState, 
    isOperatorTab, 
    setIsLoading, 
    getInitialLocalRundownState
  );
  
  const setState = useCallback(
    (updater, triggeredByOperator = false) => {
      if (isUnmountedRefHook.current) return;
      setInternalState((currentState) => {
        if (!currentState && typeof updater === 'function') {
          const initial = getInitialLocalRundownState(projectId, "Rundown Inicial");
          const updatedState = updater(initial);
          if (isOperatorTab.current || triggeredByOperator) {
            saveStateToSupabase(updatedState);
          }
          return updatedState;
        }
        if (!currentState) return null;

        const newState = typeof updater === 'function' ? updater(currentState) : { ...currentState, ...updater };
        
        if (isOperatorTab.current || triggeredByOperator) {
            saveStateToSupabase(newState);
        }
        return newState;
      });
    },
    [saveStateToSupabase, projectId] 
  );
  
  const advanceToNextItem = useCallback(() => {
    if (!state) return;
    setState(prevState => {
      tenSecondWarningPlayedRef.current = false;
      return advanceToNextItemLogic(prevState, timerRef, lastTickTimeRef);
    }, true);
  }, [setState, state]);

  const { timerRef, lastTickTimeRef } = useRundownTimer(
    state, 
    setState, 
    advanceToNextItem, 
    isOperatorTab, 
    notificationSoundRef, 
    tenSecondWarningPlayedRef, 
    projectId
  );

  const playPause = useCallback(() => {
    if (!state) return;
    setState(prevState => {
      if (prevState.projectId !== projectId) return prevState;
      if (!prevState.isRunning) { tenSecondWarningPlayedRef.current = false; }
      const logicResult = playPauseLogic(prevState, timerRef, lastTickTimeRef);
      return { ...logicResult, last_updated_by_operator_at: new Date().toISOString() };
    }, true);
  }, [setState, projectId, state, timerRef, lastTickTimeRef]);

  const resetRundown = useCallback(() => {
    if (!state) return;
    setState(prevState => {
      if (prevState.projectId !== projectId) return prevState;
      tenSecondWarningPlayedRef.current = false;
      const logicResult = resetRundownLogic(prevState, timerRef);
      return { ...logicResult, last_updated_by_operator_at: new Date().toISOString() };
    }, true);
  }, [setState, projectId, state, timerRef]);

  const selectItem = useCallback((folderIndex, itemIndex) => {
    if (!state) return;
    setState(prevState => {
      if (prevState.projectId !== projectId) return prevState;
      tenSecondWarningPlayedRef.current = false;
      const logicResult = selectItemLogic(prevState, folderIndex, itemIndex, timerRef, lastTickTimeRef);
      return { ...logicResult, last_updated_by_operator_at: new Date().toISOString() };
    }, true);
  }, [setState, projectId, state, timerRef, lastTickTimeRef]);
  
  const skipForward = useCallback(() => { advanceToNextItem(); }, [advanceToNextItem]);

  const saveFolder = useCallback((folderData, editingFolderId) => {
    if (!state) return;
    setState(prevState => {
      if (prevState.projectId !== projectId) return prevState;
      const logicResult = saveFolderLogic(prevState, folderData, editingFolderId, defaultColors);
      return { ...logicResult, last_updated_by_operator_at: new Date().toISOString() };
    }, true);
  }, [setState, projectId, state]);

  const deleteFolder = useCallback((folderId) => {
    if (!state) return;
    setState(prevState => {
      if (prevState.projectId !== projectId) return prevState;
      const logicResult = deleteFolderLogic(prevState, folderId, timerRef, lastTickTimeRef);
      return { ...logicResult, last_updated_by_operator_at: new Date().toISOString() };
    }, true);
  }, [setState, projectId, state, timerRef, lastTickTimeRef]);

  const saveEvent = useCallback((eventData, folderId, editingEventId) => {
    if (!state) return;
    setState(prevState => {
      if (prevState.projectId !== projectId) return prevState;
      const logicResult = saveEventLogic(prevState, eventData, folderId, editingEventId, defaultEventIcons);
      return { ...logicResult, last_updated_by_operator_at: new Date().toISOString() };
    }, true);
  }, [setState, projectId, state]);

  const deleteEvent = useCallback((folderId, eventId) => {
    if (!state) return;
    setState(prevState => {
      if (prevState.projectId !== projectId) return prevState;
      const logicResult = deleteEventLogic(prevState, folderId, eventId, timerRef, lastTickTimeRef);
      return { ...logicResult, last_updated_by_operator_at: new Date().toISOString() };
    }, true);
  }, [setState, projectId, state, timerRef, lastTickTimeRef]);

  return { 
    state: state || getInitialLocalRundownState(projectId),
    isLoading,
    playPause,
    resetRundown,
    selectItem,
    skipForward,
    saveFolder,
    deleteFolder,
    saveEvent,
    deleteEvent,
    defaultColors,
    defaultEventIcons,
    toast: toastEmitter,
    isOperator: isOperatorTab.current,
  };
};