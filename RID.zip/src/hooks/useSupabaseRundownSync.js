import { useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { toast as toastEmitter } from '@/components/ui/use-toast';

export const useSupabaseRundownSync = (projectId, user, setInternalState, isOperatorTab, setIsLoading, getInitialLocalRundownState) => {
  const realtimeChannelRef = useRef(null);
  const isUnmountedRef = useRef(false);

  useEffect(() => {
    isUnmountedRef.current = false;
    return () => { isUnmountedRef.current = true; };
  }, []);

  const fetchRundownData = useCallback(async () => {
    if (isUnmountedRef.current || !projectId || !user || !supabase) {
      if (setIsLoading) setIsLoading(false);
      return;
    }
    if (setIsLoading) setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('rundowns')
        .select('*')
        .eq('project_id', projectId)
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') throw error;

      if (isUnmountedRef.current) return;

      if (data) {
        setInternalState({
          rundown: {
            id: data.id, 
            title: data.title,
            eventDate: data.event_date,
            folders: data.folders || [],
          },
          currentFolderIndex: data.current_folder_index || 0,
          currentItemIndex: data.current_item_index || 0,
          elapsedTime: data.elapsed_time || 0,
          isRunning: data.is_running || false,
          projectId: data.project_id,
          last_updated_by_operator_at: data.last_updated_by_operator_at || new Date().toISOString(),
        });
      } else {
        console.warn(`No rundown data found for project ${projectId}. Using local initial state.`);
        const { data: projectDetails, error: projectError } = await supabase.from('projects').select('name').eq('id', projectId).single();
        if (projectError && projectError.code !== 'PGRST116') console.error("Error fetching project name for initial state:", projectError);
        
        if (isUnmountedRef.current) return;
        setInternalState(getInitialLocalRundownState(projectId, projectDetails?.name || "Novo Rundown"));
      }
    } catch (error) {
      console.error('Error fetching rundown data:', error);
      toastEmitter({ title: "Erro ao Carregar Rundown", description: error.message, variant: "destructive" });
      if (isUnmountedRef.current) return;
      setInternalState(getInitialLocalRundownState(projectId, "Rundown com Erro"));
    } finally {
      if (!isUnmountedRef.current && setIsLoading) setIsLoading(false);
    }
  }, [projectId, user, setInternalState, setIsLoading, getInitialLocalRundownState]);

  useEffect(() => {
    fetchRundownData();
  }, [fetchRundownData]);

  const saveStateToSupabase = useCallback(async (newState) => {
    if (isUnmountedRef.current || !projectId || !user || !supabase || !newState || !newState.rundown) return;
    
    const payload = {
      project_id: projectId,
      user_id: user.id,
      title: newState.rundown.title,
      event_date: newState.rundown.eventDate,
      folders: newState.rundown.folders,
      current_folder_index: newState.currentFolderIndex,
      current_item_index: newState.currentItemIndex,
      is_running: newState.isRunning,
      elapsed_time: newState.elapsedTime,
      last_updated_by_operator_at: new Date().toISOString(),
    };

    try {
      const { error } = await supabase
        .from('rundowns')
        .upsert(payload, { onConflict: 'project_id, user_id' }); 
      
      if (error) throw error;
    } catch (error) {
      console.error('Error saving state to Supabase:', error);
      toastEmitter({ title: "Erro ao Salvar no Servidor", description: error.message, variant: "destructive" });
    }
  }, [projectId, user]);

  useEffect(() => {
    if (isUnmountedRef.current || !projectId || !supabase || !user?.id) return; 

    if (realtimeChannelRef.current) {
        supabase.removeChannel(realtimeChannelRef.current).catch(err => console.error("Error removing old channel:", err));
        realtimeChannelRef.current = null;
    }

    const channel = supabase
      .channel(`rundown_updates_${projectId}`)
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'rundowns', filter: `project_id=eq.${projectId}` },
        (payload) => {
          if (isUnmountedRef.current) return;

          if (isOperatorTab.current && payload.eventType === 'UPDATE' && payload.new.user_id === user?.id) {
            return;
          }
          
          const updatedData = payload.new;
          if (updatedData) {
            setInternalState({
              rundown: {
                id: updatedData.project_id, 
                title: updatedData.title,
                eventDate: updatedData.event_date,
                folders: updatedData.folders || [],
              },
              currentFolderIndex: updatedData.current_folder_index || 0,
              currentItemIndex: updatedData.current_item_index || 0,
              elapsedTime: updatedData.elapsed_time || 0,
              isRunning: updatedData.is_running || false,
              projectId: updatedData.project_id,
              last_updated_by_operator_at: updatedData.last_updated_by_operator_at,
            });
          }
        }
      )
      .subscribe((status, err) => {
        if (isUnmountedRef.current) return;
        if (status === 'SUBSCRIBED') {
          console.log(`Subscribed to rundown updates for project ${projectId}`);
        }
        if (status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' || err) {
          console.error(`Error subscribing to rundown updates for project ${projectId}:`, err || status);
        }
      });
      
      realtimeChannelRef.current = channel;

    return () => {
      if (realtimeChannelRef.current && supabase) {
        supabase.removeChannel(realtimeChannelRef.current).catch(err => console.error("Error removing channel on unmount:", err));
        realtimeChannelRef.current = null;
      }
    };
  }, [projectId, supabase, user?.id, setInternalState, isOperatorTab]);
  
  return { saveStateToSupabase };
};