import { useEffect, useRef } from 'react';
import { playSound } from '@/lib/audioUtils';

export const useRundownTimer = (state, setState, advanceToNextItem, isOperatorTab, notificationSoundRef, tenSecondWarningPlayedRef, projectId) => {
  const timerRef = useRef(null);
  const lastTickTimeRef = useRef(Date.now());
  const isUnmountedRef = useRef(false);

  useEffect(() => {
    isUnmountedRef.current = false;
    return () => { 
      isUnmountedRef.current = true;
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = null;
    };
  }, []);

  useEffect(() => {
    if (!state) return;

    const tick = () => {
      if (isUnmountedRef.current || !state.isRunning) {
        if (timerRef.current) clearInterval(timerRef.current);
        timerRef.current = null;
        return;
      }
      
      const currentTime = Date.now();
      const deltaTime = (currentTime - lastTickTimeRef.current) / 1000;
      lastTickTimeRef.current = currentTime;

      setState((prevState) => {
        if (!prevState || !prevState.isRunning || prevState.projectId !== projectId) return prevState;
        if (!prevState.rundown || !prevState.rundown.folders || prevState.rundown.folders.length === 0) {
          if (isOperatorTab.current) advanceToNextItem(); 
          return { ...prevState, isRunning: false };
        }
        
        const currentFolder = prevState.rundown.folders[prevState.currentFolderIndex];
        if (!currentFolder || !currentFolder.events || currentFolder.events.length === 0) { 
          if (isOperatorTab.current) advanceToNextItem(); 
          return prevState; 
        }
        
        const currentItem = currentFolder.events[prevState.currentItemIndex];
        if (!currentItem) { 
          if (isOperatorTab.current) advanceToNextItem(); 
          return prevState; 
        }

        const newElapsedTime = prevState.elapsedTime + deltaTime;
        const remainingTime = currentItem.duration - newElapsedTime;

        if (isOperatorTab.current && remainingTime <= 10.25 && remainingTime > 9.75 && !tenSecondWarningPlayedRef.current && notificationSoundRef.current) {
           playSound(notificationSoundRef.current);
           tenSecondWarningPlayedRef.current = true;
        }

        if (newElapsedTime >= currentItem.duration) { 
          if (isOperatorTab.current) advanceToNextItem(); 
          return prevState; 
        }
        return { ...prevState, elapsedTime: newElapsedTime };
      }, isOperatorTab.current);
    };

    if (isOperatorTab.current && state.isRunning && state.projectId === projectId) {
      if (timerRef.current) clearInterval(timerRef.current);
      lastTickTimeRef.current = Date.now(); 
      timerRef.current = setInterval(tick, 250); 
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = null;
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = null;
    };
  }, [state?.isRunning, state?.currentFolderIndex, state?.currentItemIndex, state?.rundown, state?.projectId, setState, advanceToNextItem, projectId, isOperatorTab, notificationSoundRef, tenSecondWarningPlayedRef, state]);

  return { timerRef, lastTickTimeRef };
};