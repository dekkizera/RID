import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import * as LucideIcons from 'lucide-react';
import { Download, Eye, Search, Users2, UploadCloud, Filter, Star, ThumbsUp, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import MainLayout from '@/components/MainLayout';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/AuthContext';
import { defaultColors } from '@/lib/constants'; 

const RenderTemplateIcon = ({ iconName, className = "w-8 h-8" }) => {
  const IconComponent = LucideIcons[iconName] || LucideIcons.FileText;
  return <IconComponent className={cn(className)} />;
};


const CommunityPageContent = () => {
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate(); 

  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('Todos');
  const [templates, setTemplates] = useState([]); 
  const [isLoadingTemplates, setIsLoadingTemplates] = useState(true);
  const [isDownloading, setIsDownloading] = useState(null); 

  const fetchCommunityTemplates = useCallback(async () => {
    if (!supabase) {
      setIsLoadingTemplates(false);
      toast({
        title: "Supabase Não Conectado",
        description: "A funcionalidade da comunidade requer integração com o Supabase. Por favor, complete a configuração.",
        variant: "destructive",
        duration: 7000
      });
      return;
    }
    setIsLoadingTemplates(true);
    try {
      const { data, error } = await supabase
        .from('community_templates')
        .select(`
          id, 
          name, 
          description, 
          category, 
          icon, 
          shared_at, 
          downloads,
          structure,
          user_id 
        `) 
        .order('shared_at', { ascending: false });
      
      if (error) throw error;

      const authorIds = data.map(t => t.user_id).filter(id => id);
      let authorsMap = {};
      if (authorIds.length > 0) {
        const { data: authorsData, error: authorsError } = await supabase
          .from('users') 
          .select('id, email') 
          .in('id', authorIds);
        if (authorsError) console.warn("Error fetching authors:", authorsError);
        else authorsData.forEach(author => authorsMap[author.id] = author.email?.split('@')[0] || 'Desconhecido');
      }
      
      const formattedTemplates = data.map(t => ({
        ...t,
        author: authorsMap[t.user_id] || 'Comunidade RID' 
      }));
      setTemplates(formattedTemplates);

    } catch (error) {
      console.error("Error fetching community templates:", error);
      toast({ title: "Erro ao Carregar Templates", description: error.message, variant: "destructive" });
    } finally {
      setIsLoadingTemplates(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchCommunityTemplates();
  }, [fetchCommunityTemplates]);


  const categories = ['Todos', ...new Set(templates.map(t => t.category))];

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          template.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          template.author.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === 'Todos' || template.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const handleDownloadTemplate = async (template) => {
    if (!user || !supabase) {
      toast({ title: "Ação Requer Login e Supabase", description: "Faça login e conecte o Supabase para baixar templates.", variant: "destructive" });
      return;
    }
    setIsDownloading(template.id);
    try {
      const { data: newProjectData, error: projectError } = await supabase
        .from('projects')
        .insert({ name: `Cópia de ${template.name}`, user_id: user.id })
        .select()
        .single();
      if (projectError) throw projectError;

      const templateStructure = template.structure || { folders: [{ id: crypto.randomUUID(), title: 'Nova Pasta (Template)', color: defaultColors[0], events: [] }] };
      
      const { error: rundownError } = await supabase
        .from('rundowns')
        .insert({
          project_id: newProjectData.id,
          user_id: user.id,
          title: newProjectData.name,
          event_date: new Date().toLocaleDateString(),
          folders: templateStructure.folders,
          current_folder_index: 0,
          current_item_index: 0,
          is_running: false,
          elapsed_time: 0,
          last_updated_by_operator_at: new Date().toISOString(),
        });
      
      if (rundownError) {
        await supabase.from('projects').delete().eq('id', newProjectData.id); 
        throw rundownError;
      }

      const { error: downloadCountError } = await supabase.rpc('increment_template_downloads', { template_id_param: template.id });
      if (downloadCountError) console.warn("Error incrementing download count:", downloadCountError);
      else {
        setTemplates(prev => prev.map(t => t.id === template.id ? {...t, downloads: (t.downloads || 0) + 1} : t));
      }

      toast({
        title: "Template Baixado!",
        description: `O template "${template.name}" foi adicionado aos seus projetos como "${newProjectData.name}".`,
        action: <Button onClick={() => navigate('/')}>Ver Meus Projetos</Button>,
        duration: 5000,
      });

    } catch (error) {
      console.error("Error downloading template:", error);
      toast({ title: "Erro ao Baixar Template", description: error.message, variant: "destructive" });
    } finally {
      setIsDownloading(null);
    }
  };

  const handleViewStructure = (templateName) => {
     toast({
      title: "Visualizar Estrutura",
      description: `A visualização da estrutura para "${templateName}" ainda não está implementada.`,
    });
  };
  
  const handleFeatureRequest = (feature) => {
    toast({
      title: "Funcionalidade em Breve!",
      description: `A funcionalidade de "${feature}" será adicionada em futuras atualizações. Obrigado pelo seu interesse!`,
    });
  }


  return (
    <div className="text-white">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="mb-8 p-6 bg-slate-800/50 backdrop-blur-md rounded-xl shadow-xl border border-slate-700"
      >
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <h2 className="text-3xl font-bold text-sky-400 flex items-center gap-2">
              <Users2 className="w-8 h-8" /> Projetos da Comunidade
            </h2>
            <p className="text-slate-400 mt-1">Explore e baixe templates de rundown criados por outros usuários.</p>
          </div>
          <Button onClick={() => handleFeatureRequest("Upload de Projetos")} className="bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-2">
            <UploadCloud className="w-5 h-5" /> Compartilhe seu Projeto
          </Button>
        </div>
        
        <div className="mt-6 flex flex-col md:flex-row gap-4">
          <div className="relative flex-grow">
            <Input 
              type="search"
              placeholder="Buscar templates por nome, autor, descrição..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-slate-700 border-slate-600 placeholder-slate-500 pl-10 py-3 text-base"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
          </div>
          <div className="relative">
            <select
              value={filterCategory}
              onChange={(e) => setFilterCategory(e.target.value)}
              className="bg-slate-700 border-slate-600 rounded-md py-3 pl-3 pr-10 text-base focus:ring-sky-500 focus:border-sky-500 appearance-none w-full md:w-auto"
            >
              {categories.map(cat => (
                <option key={cat} value={cat} className="bg-slate-800 text-white">{cat}</option>
              ))}
            </select>
             <Filter className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 pointer-events-none" />
          </div>
        </div>
      </motion.div>

      <AnimatePresence>
        {isLoadingTemplates ? (
           <motion.div key="loader-community" className="flex justify-center items-center py-20">
            <Loader2 className="w-16 h-16 animate-spin text-purple-400" />
          </motion.div>
        ) : filteredTemplates.length === 0 ? (
          <motion.div
            key="no-results"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="text-center py-20"
          >
            <Search className="w-20 h-20 mx-auto text-slate-600 mb-6" />
            <p className="text-2xl text-slate-400 mb-3">Nenhum template encontrado.</p>
            <p className="text-slate-500">Tente ajustar seus filtros ou busca. (Ou o Supabase não está conectado)</p>
          </motion.div>
        ) : (
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            variants={{
              container: { transition: { staggerChildren: 0.08 }}
            }}
            initial="container"
            animate="container"
          >
            {filteredTemplates.map((template) => (
              <motion.div
                key={template.id}
                layout
                variants={{ 
                    initial: { opacity: 0, y: 40, scale: 0.9 }, 
                    animate: { opacity: 1, y: 0, scale: 1 },
                    exit: { opacity: 0, y: -20, scale: 0.95 }
                }}
                transition={{ type: "spring", stiffness: 220, damping: 25 }}
                className="bg-slate-800/60 border border-slate-700 rounded-xl shadow-lg p-6 hover:shadow-purple-500/20 transition-shadow duration-300 flex flex-col"
              >
                <div className="flex items-start justify-between mb-3">
                  <RenderTemplateIcon iconName={template.icon} className="w-10 h-10 text-purple-400" />
                  <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-1 rounded-full">{template.category}</span>
                </div>
                <h3 className="text-xl font-semibold text-purple-300 mb-2 truncate" title={template.name}>{template.name}</h3>
                <p className="text-sm text-slate-400 mb-3 flex-grow min-h-[60px] line-clamp-3" title={template.description}>{template.description}</p>
                
                <div className="text-xs text-slate-500 mb-4 space-y-1">
                  <p>Por: <span className="font-medium text-slate-400">{template.author}</span></p>
                  <p>Compartilhado em: {new Date(template.shared_at).toLocaleDateString()}</p>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 mb-5">
                    <span className="flex items-center gap-1" title="Downloads">
                        <Download className="w-3.5 h-3.5"/> {template.downloads || 0}
                    </span>
                </div>

                <div className="mt-auto flex flex-col sm:flex-row gap-2">
                  <Button 
                    onClick={() => handleDownloadTemplate(template)} 
                    className="flex-1 bg-purple-600 hover:bg-purple-700 text-white flex items-center justify-center gap-2"
                    disabled={isDownloading === template.id}
                  >
                    {isDownloading === template.id ? <Loader2 className="w-4 h-4 animate-spin mr-1" /> : <Download className="w-4 h-4" />}
                    {isDownloading === template.id ? "Baixando..." : "Baixar"}
                  </Button>
                  <Button 
                    onClick={() => handleViewStructure(template.name)} 
                    variant="outline" 
                    className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700/50 hover:text-slate-100 flex items-center justify-center gap-2"
                  >
                    <Eye className="w-4 h-4" /> Estrutura
                  </Button>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const WrappedCommunityPage = () => (
  <MainLayout>
    <CommunityPageContent />
  </MainLayout>
);

export { WrappedCommunityPage as CommunityPage };