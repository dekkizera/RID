import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { User, Radio } from 'lucide-react';
import { Button } from '@/components/ui/button';

const HomePage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center"
      >
        <h1 className="text-5xl font-bold text-primary mb-4">Bem-vindo ao RundownPRO</h1>
        <p className="text-xl text-muted-foreground mb-12">Selecione seu perfil para iniciar</p>
        <div className="flex justify-center gap-8">
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={() => navigate('/operator')}
              className="h-32 w-64 text-xl flex-col gap-2 bg-secondary hover:bg-secondary/80"
            >
              <Radio className="w-10 h-10 mb-2" />
              Operador
            </Button>
          </motion.div>
          <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
            <Button
              onClick={() => navigate('/presenter')}
              className="h-32 w-64 text-xl flex-col gap-2 bg-secondary hover:bg-secondary/80"
            >
              <User className="w-10 h-10 mb-2" />
              Apresentador
            </Button>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
};

export default HomePage;