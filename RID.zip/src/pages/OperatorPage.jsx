
import React, { useEffect, useRef } from 'react';
import Header from '@/components/Header';
import OperatorRundown from '@/components/OperatorRundown';
import { useParams } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/components/ui/use-toast';

const OperatorPage = () => {
  const { projectId } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const isUnloadingRef = useRef(false);

  const updateRundownSessionStatus = async (isActive, showAlertOnError = false) => {
    if (!projectId || !user || !supabase) return;

    try {
      const { data: existingRundown, error: fetchError } = await supabase
        .from('rundowns')
        .select('id')
        .eq('project_id', projectId)
        .eq('user_id', user.id)
        .maybeSingle();

      if (fetchError && fetchError.code !== 'PGRST116') { 
        throw fetchError;
      }
      
      if (!existingRundown && isActive) {
        console.warn(`OperatorPage: Rundown record for project ${projectId} does not exist. Status update for 'isActive' skipped. The main sync hook should create it.`);
        return; 
      }
      
      if (existingRundown) {
        const { error: updateError } = await supabase
          .from('rundowns')
          .update({ 
            is_running: isActive, // This might be better handled by the playPause logic directly
            last_updated_by_operator_at: new Date().toISOString() 
          })
          .eq('project_id', projectId)
          .eq('user_id', user.id);
        if (updateError) throw updateError;
        console.log(`OperatorPage: Rundown session status updated to ${isActive ? 'active' : 'inactive'}`);
      }

    } catch (error) {
      console.error('OperatorPage: Error updating rundown session status:', error);
      if (showAlertOnError && !isUnloadingRef.current) {
        toast({
          title: 'Erro de Sessão do Operador',
          description: `Não foi possível atualizar o status da sessão: ${error.message}`,
          variant: 'destructive',
        });
      }
    }
  };

  useEffect(() => {
    isUnloadingRef.current = false;
    if (projectId && user) {
      updateRundownSessionStatus(true, true); 
    }
    
    const handleBeforeUnload = () => {
      isUnloadingRef.current = true;
      if (projectId && user) {
        // Use a synchronous request if possible, or accept it might not complete
        // For navigator.sendBeacon, the data must be of a specific type
        // Here, we'll just call the async function, understanding it's best-effort
        updateRundownSessionStatus(false, false); 
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      if (!isUnloadingRef.current && projectId && user) { // Check if not already unloading
         updateRundownSessionStatus(false, false); 
      }
    };
  }, [projectId, user]);

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <OperatorRundown />
      </main>
    </div>
  );
};

export default OperatorPage;
