
import React, { useEffect, useState, useCallback } from 'react';
import Header from '@/components/Header';
import PresenterRundown from '@/components/PresenterRundown';
import { useAuth } from '@/contexts/AuthContext';
import { useParams } from 'react-router-dom';
import { WifiOff, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';

const PresenterPage = () => {
  const { projectId } = useParams();
  const { user } = useAuth(); // User might not be strictly needed here if presenter view is public based on session
  const [sessionActive, setSessionActive] = useState(null); 
  const [isLoadingSession, setIsLoadingSession] = useState(true);

  const checkSessionStatus = useCallback(async () => {
    if (!projectId || !supabase) {
      setSessionActive(false);
      setIsLoadingSession(false);
      return;
    }
    setIsLoadingSession(true);
    try {
      const { data, error } = await supabase
        .from('rundowns')
        .select('is_running, last_updated_by_operator_at')
        .eq('project_id', projectId)
        .single();

      if (error && error.code !== 'PGRST116') { // PGRST116: 0 rows means no rundown found
        console.error('Error fetching project session status:', error);
        setSessionActive(false);
        setIsLoadingSession(false);
        return;
      }
      
      if (!data) { // No rundown data for this project
        setSessionActive(false);
        setIsLoadingSession(false);
        return;
      }

      const isActive = data.is_running;
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
      const isRecent = data.last_updated_by_operator_at > fiveMinutesAgo;
      
      setSessionActive(isActive && isRecent);
    } catch (err) {
      console.error('Exception fetching project session status:', err);
      setSessionActive(false);
    } finally {
      setIsLoadingSession(false);
    }
  }, [projectId]);
  
  useEffect(() => {
    checkSessionStatus(); // Initial check
    
    // Realtime subscription for rundown changes
    let channel = null;
    if (supabase && projectId) {
      channel = supabase
        .channel(`presenter_rundown_status_${projectId}`)
        .on(
          'postgres_changes',
          { event: '*', schema: 'public', table: 'rundowns', filter: `project_id=eq.${projectId}` },
          (payload) => {
            console.log('Presenter received rundown update:', payload);
            checkSessionStatus(); // Re-check session status on any change to the rundown
          }
        )
        .subscribe((status, err) => {
          if (status === 'SUBSCRIBED') {
            console.log(`Presenter subscribed to rundown ${projectId}`);
          }
          if (err) {
            console.error(`Error subscribing to rundown ${projectId} for presenter:`, err);
          }
        });
    }

    return () => {
      if (channel && supabase) {
        supabase.removeChannel(channel).catch(err => console.error("Error removing presenter channel:", err));
      }
    };
  }, [projectId, checkSessionStatus]);


  if (isLoadingSession) {
    return (
      <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center">
        <Loader2 className="w-16 h-16 animate-spin text-sky-500 mb-4" />
        <p className="text-xl text-slate-400">Verificando status da sessão...</p>
      </div>
    );
  }

  if (!sessionActive) {
    return (
      <div className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center text-center p-8">
        <WifiOff className="w-24 h-24 text-red-500 mb-6" />
        <h1 className="text-3xl font-bold text-slate-200 mb-3">Operação Não Iniciada</h1>
        <p className="text-lg text-slate-400 max-w-md">
          O rundown para este projeto não está sendo operado no momento ou a sessão expirou.
          Por favor, aguarde o operador iniciar/retomar a sessão ou contate o responsável.
        </p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <PresenterRundown />
      </main>
    </div>
  );
};

export default PresenterPage;
