import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom'; // Import Link
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tv, AlertCircle, Loader2, UserPlus } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';

const LoginPage = () => {
  const [email, setEmail] = useState(''); 
  const [password, setPassword] = useState(''); 
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const { login, user, loading, setLoading } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (user && !loading) { // Ensure not loading before navigating
      navigate('/');
    }
  }, [user, loading, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsSubmitting(true);
    setLoading(true); // Context loading
    try {
      await login(email, password);
      toast({ title: "Login Bem-sucedido!", description: "Bem-vindo de volta! Redirecionando...", duration: 3000 });
      navigate('/'); 
    } catch (err) {
      console.error("Login page error:", err);
      let errorMessage = 'Falha ao fazer login. Verifique suas credenciais.';
      if (err.message) {
        if (err.message.toLowerCase().includes('invalid login credentials')) {
          errorMessage = 'Credenciais de login inválidas. Por favor, verifique seu email e senha.';
        } else if (err.message.toLowerCase().includes('email not confirmed')) {
          errorMessage = 'Seu email ainda não foi confirmado. Por favor, verifique sua caixa de entrada.';
        } else if (err.message.toLowerCase().includes('user not found') || err.message.toLowerCase().includes('user does not exist')) {
          errorMessage = 'Usuário não encontrado. Considere se cadastrar.';
        } else {
          errorMessage = `Erro: ${err.message}`;
        }
      }
      setError(errorMessage);
      toast({ title: "Erro de Login", description: errorMessage, variant: "destructive" });
    } finally {
      setIsSubmitting(false);
      setLoading(false); // Context loading
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-900 flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="flex items-center gap-3 mb-10 text-white"
      >
        <Tv className="w-12 h-12 text-sky-400" />
        <h1 className="text-5xl font-bold tracking-tight">
          Run It Down <span className="text-sky-400">(RID)</span>
        </h1>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, delay: 0.2, ease: "easeOut" }}
      >
        <Card className="w-full max-w-md bg-slate-800/70 border-slate-700 shadow-2xl backdrop-blur-md">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-white">Login</CardTitle>
            <CardDescription className="text-slate-400 pt-1">Acesse para gerenciar seus rundowns.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-300">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seuemail@exemplo.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-500 focus:ring-sky-500"
                  disabled={isSubmitting || loading}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-300">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="********"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-500 focus:ring-sky-500"
                  disabled={isSubmitting || loading}
                />
              </div>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center p-3 bg-red-500/20 border border-red-500/50 text-red-300 rounded-md text-sm"
                >
                  <AlertCircle className="w-5 h-5 mr-2 flex-shrink-0" />
                  {error}
                </motion.div>
              )}
              <Button 
                type="submit" 
                className="w-full bg-sky-500 hover:bg-sky-600 text-white text-lg py-6 transition-all duration-300 ease-in-out transform hover:scale-105 flex items-center justify-center"
                disabled={isSubmitting || loading}
              >
                {(isSubmitting || loading) ? <Loader2 className="w-6 h-6 animate-spin mr-2" /> : null}
                {(isSubmitting || loading) ? 'Entrando...' : 'Entrar'}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex flex-col items-center space-y-2 pt-4">
            <p className="text-xs text-slate-500">
              Não tem uma conta?{' '}
              <Link to="/signup" className="font-medium text-sky-400 hover:text-sky-300 hover:underline">
                Cadastre-se aqui
              </Link>
            </p>
          </CardFooter>
        </Card>
      </motion.div>
       <motion.p 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.5 }}
        className="mt-12 text-center text-sm text-slate-500"
      >
        Plataforma de gerenciamento de rundown profissional.
        <br />© {new Date().getFullYear()} Run It Down (RID). Todos os direitos reservados.
      </motion.p>
    </div>
  );
};

export default LoginPage;