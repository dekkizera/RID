
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { PlusCircle, Settings, Trash2, Edit3, Eye, Copy, ExternalLink, RadioTower, UploadCloud, Loader2, AlertTriangle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import MainLayout from '@/components/MainLayout';
import { supabase } from '@/lib/supabaseClient';
import { defaultColors, defaultEventIcons } from '@/lib/constants'; // For new rundown structure

const DashboardPageContent = () => {
  const navigate = useNavigate();
  const { user, isProjectSessionActive: checkSessionActive } = useAuth();
  const { toast } = useToast();

  const [projects, setProjects] = useState([]);
  const [isLoadingProjects, setIsLoadingProjects] = useState(true);
  const [isCreateProjectModalOpen, setIsCreateProjectModalOpen] = useState(false);
  const [newProjectName, setNewProjectName] = useState('');
  const [editingProject, setEditingProject] = useState(null);
  const [activeSessions, setActiveSessions] = useState({});
  const [isSubmittingProject, setIsSubmittingProject] = useState(false);

  const fetchProjects = useCallback(async () => {
    if (!user || !supabase) return;
    setIsLoadingProjects(true);
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('id, name, created_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProjects(data || []);
    } catch (error) {
      console.error('Error fetching projects:', error);
      toast({ title: "Erro ao Carregar Projetos", description: error.message, variant: "destructive" });
    } finally {
      setIsLoadingProjects(false);
    }
  }, [user, toast]);

  const updateActiveSessions = useCallback(async () => {
    if (!projects.length || !supabase) return;
    const currentActiveSessions = {};
    for (const p of projects) {
      if (await checkSessionActive(p.id)) {
        currentActiveSessions[p.id] = true;
      }
    }
    setActiveSessions(currentActiveSessions);
  }, [projects, checkSessionActive]);
  
  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  useEffect(() => {
    updateActiveSessions();
    const intervalId = setInterval(updateActiveSessions, 15000); // Check active sessions periodically
    return () => clearInterval(intervalId);
  }, [updateActiveSessions]);


  const handleCreateOrEditProject = async () => {
    if (!newProjectName.trim()) {
      toast({ title: "Erro", description: "O nome do projeto não pode estar vazio.", variant: "destructive" });
      return;
    }
    if (!user || !supabase) return;

    setIsSubmittingProject(true);
    try {
      if (editingProject) { // Editing existing project
        const { error } = await supabase
          .from('projects')
          .update({ name: newProjectName })
          .eq('id', editingProject.id)
          .eq('user_id', user.id);
        if (error) throw error;
        toast({ title: "Sucesso!", description: `Projeto "${newProjectName}" atualizado.` });
      } else { // Creating new project
        const { data: newProjectData, error: projectError } = await supabase
          .from('projects')
          .insert({ name: newProjectName, user_id: user.id })
          .select()
          .single();
        if (projectError) throw projectError;

        // Create an initial empty rundown structure for the new project
        const initialRundownStructure = {
          id: newProjectData.id, // Use project ID as rundown ID for simplicity or generate new
          title: newProjectName,
          eventDate: new Date().toLocaleDateString(),
          folders: [{ id: crypto.randomUUID(), title: 'Nova Pasta', color: defaultColors[0], events: [] }],
          currentFolderIndex: 0,
          currentItemIndex: 0,
          elapsedTime: 0,
          isRunning: false,
          last_updated_by_operator_at: new Date().toISOString(),
        };

        const { error: rundownError } = await supabase
          .from('rundowns')
          .insert({
            project_id: newProjectData.id,
            user_id: user.id,
            title: initialRundownStructure.title,
            event_date: initialRundownStructure.eventDate,
            folders: initialRundownStructure.folders,
            current_folder_index: initialRundownStructure.currentFolderIndex,
            current_item_index: initialRundownStructure.currentItemIndex,
            is_running: initialRundownStructure.isRunning,
            elapsed_time: initialRundownStructure.elapsedTime,
            last_updated_by_operator_at: initialRundownStructure.last_updated_by_operator_at,
          });
        
        if (rundownError) {
          // Attempt to delete the project if rundown creation fails to avoid orphaned projects
          await supabase.from('projects').delete().eq('id', newProjectData.id);
          throw rundownError;
        }
        toast({ title: "Sucesso!", description: `Projeto "${newProjectName}" criado.` });
      }
      fetchProjects(); // Refresh project list
      setNewProjectName('');
      setEditingProject(null);
      setIsCreateProjectModalOpen(false);
    } catch (error) {
      console.error('Error saving project:', error);
      toast({ title: "Erro ao Salvar Projeto", description: error.message, variant: "destructive" });
    } finally {
      setIsSubmittingProject(false);
    }
  };

  const handleDeleteProject = async (projectId, projectName) => {
    if (!user || !supabase) return;
    
    // Simple confirm for now, ideally use AlertDialog component
    if (window.confirm(`Tem certeza que deseja deletar o projeto "${projectName}"? Esta ação não pode ser desfeita e todos os dados do rundown associados serão perdidos.`)) {
      try {
        // It's good practice to delete related data first, or use CASCADE delete in DB
        const { error: rundownDeleteError } = await supabase
          .from('rundowns')
          .delete()
          .eq('project_id', projectId)
          .eq('user_id', user.id);

        // Allow project deletion even if rundown deletion fails or no rundown exists
        if (rundownDeleteError && rundownDeleteError.code !== 'PGRST116') { // PGRST116: 0 rows
            console.warn('Error deleting rundown data, but proceeding with project deletion:', rundownDeleteError);
        }

        const { error: projectDeleteError } = await supabase
          .from('projects')
          .delete()
          .eq('id', projectId)
          .eq('user_id', user.id);

        if (projectDeleteError) throw projectDeleteError;

        toast({ title: "Projeto Deletado", description: `Projeto "${projectName}" foi removido.`, variant: "default" });
        fetchProjects(); // Refresh project list
        setActiveSessions(prev => { const newState = {...prev}; delete newState[projectId]; return newState; });
      } catch (error) {
        console.error('Error deleting project:', error);
        toast({ title: "Erro ao Deletar Projeto", description: error.message, variant: "destructive" });
      }
    }
  };

  const handleOpenProject = (projectId) => {
    navigate(`/project/${projectId}/operator`);
  };
  
  const handleCopyPresenterLink = async (projectId) => {
    if (!await checkSessionActive(projectId)) {
      toast({ title: "Operação Inativa", description: "Este rundown não está sendo operado no momento." });
      return;
    }
    const presenterUrl = `${window.location.origin}/project/${projectId}/presenter`;
    navigator.clipboard.writeText(presenterUrl).then(() => {
      toast({ title: "Link Copiado!", description: "Link do apresentador copiado." });
    }, (err) => {
      toast({ title: "Erro ao Copiar", description: "Não foi possível copiar o link.", variant: "destructive" });
    });
  };

  const handleViewPresenter = async (projectId) => {
     if (!await checkSessionActive(projectId)) {
      toast({ title: "Operação Inativa", description: "Este rundown não está sendo operado no momento." });
      return;
    }
    const presenterUrl = `${window.location.origin}/project/${projectId}/presenter`;
    window.open(presenterUrl, '_blank', 'noopener,noreferrer');
  };
  
  const handleShareToCommunity = (project) => {
    toast({
      title: "Compartilhar Projeto",
      description: `A funcionalidade de compartilhar "${project.name}" com a comunidade ainda não foi implementada.`,
    });
  }

  return (
    <>
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4"
      >
        <h2 className="text-3xl sm:text-4xl font-semibold text-slate-100">Meus Projetos</h2>
        <Button 
          onClick={() => { setEditingProject(null); setNewProjectName(''); setIsCreateProjectModalOpen(true); }}
          className="bg-sky-500 hover:bg-sky-600 text-white text-base py-3 px-6 transition-all duration-300 ease-in-out transform hover:scale-105 shadow-lg flex items-center gap-2"
        >
          <PlusCircle className="w-5 h-5" />
          Novo Projeto
        </Button>
      </motion.div>

      <AnimatePresence>
        {isLoadingProjects ? (
          <motion.div key="loader" className="flex justify-center items-center py-16">
            <Loader2 className="w-12 h-12 animate-spin text-sky-400" />
          </motion.div>
        ) : projects.length === 0 ? (
          <motion.div
            key="empty-state"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.3 }}
            className="text-center py-16"
          >
            <Settings className="w-24 h-24 mx-auto text-slate-600 mb-6 opacity-50" />
            <p className="text-2xl text-slate-400 mb-4">Nenhum projeto encontrado.</p>
            <p className="text-slate-500">Comece criando seu primeiro projeto de rundown!</p>
          </motion.div>
        ) : (
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            variants={{
              hidden: { opacity: 0 },
              show: { opacity: 1, transition: { staggerChildren: 0.07, delayChildren: 0.1 }}
            }}
            initial="hidden"
            animate="show"
            exit="hidden" 
          >
            {projects.map((project) => (
              <motion.div
                key={project.id}
                layout
                variants={{ 
                  hidden: { y: 30, opacity: 0, scale: 0.95 }, 
                  show: { y: 0, opacity: 1, scale: 1 },
                }}
                transition={{ type: "spring", stiffness: 260, damping: 20 }}
                className="bg-slate-800/70 border border-slate-700 rounded-xl shadow-xl p-6 hover:shadow-sky-500/30 transition-all duration-300 flex flex-col justify-between relative overflow-hidden"
              >
                {activeSessions[project.id] && (
                  <motion.div 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="absolute top-3 right-3 text-white text-xs px-2 py-0.5 rounded-full flex items-center gap-1 shadow-md bg-green-500/80"
                    title="Sessão Ativa"
                  >
                     <RadioTower className="w-3 h-3" /> Operando
                  </motion.div>
                )}
                <div>
                  <h3 className="text-2xl font-semibold text-sky-400 mb-2 truncate" title={project.name}>{project.name}</h3>
                  <p className="text-xs text-slate-500 mb-4">Criado em: {new Date(project.created_at).toLocaleDateString()}</p>
                </div>
                <div className="mt-auto flex flex-col space-y-2">
                   <Button 
                      onClick={() => handleOpenProject(project.id)}
                      className="w-full bg-green-600 hover:bg-green-700 text-white flex items-center justify-center gap-2"
                    >
                      <Eye className="w-4 h-4" /> Abrir Operador
                    </Button>
                    <div className="flex gap-2">
                      <Button 
                        onClick={() => handleViewPresenter(project.id)}
                        variant="outline"
                        disabled={!activeSessions[project.id]}
                        className="w-full border-sky-600 text-sky-400 hover:bg-sky-500/10 hover:text-sky-300 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:border-slate-700 disabled:text-slate-600"
                      >
                        <ExternalLink className="w-4 h-4" /> Ver Apres.
                      </Button>
                       <Button 
                        onClick={() => handleCopyPresenterLink(project.id)}
                        variant="outline"
                        disabled={!activeSessions[project.id]}
                        className="w-full border-slate-600 text-slate-400 hover:bg-slate-700/50 hover:text-slate-300 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:border-slate-700 disabled:text-slate-600"
                      >
                        <Copy className="w-4 h-4" /> Copiar Link
                      </Button>
                    </div>
                  <div className="flex gap-2 mt-2">
                    <Button onClick={() => handleShareToCommunity(project)} variant="outline" size="sm" className="flex-1 border-purple-600 text-purple-400 hover:bg-purple-500/10 hover:text-purple-300">
                      <UploadCloud className="w-4 h-4 mr-1" /> Compartilhar
                    </Button>
                    <Button onClick={() => { setEditingProject(project); setNewProjectName(project.name); setIsCreateProjectModalOpen(true); }} variant="outline" size="sm" className="flex-1 border-slate-600 text-slate-400 hover:bg-slate-700/50 hover:text-slate-200">
                      <Edit3 className="w-4 h-4 mr-1" /> Renomear
                    </Button>
                    <Button onClick={() => handleDeleteProject(project.id, project.name)} variant="ghost" size="sm" className="flex-1 text-red-500 hover:bg-red-500/10 hover:text-red-400">
                      <Trash2 className="w-4 h-4 mr-1" /> Deletar
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <Dialog open={isCreateProjectModalOpen} onOpenChange={(isOpen) => {
        setIsCreateProjectModalOpen(isOpen);
        if (!isOpen) {
          setEditingProject(null); 
          setNewProjectName('');
        }
      }}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white shadow-2xl">
          <DialogHeader>
            <DialogTitle className="text-2xl text-sky-400">{editingProject ? "Renomear Projeto" : "Criar Novo Projeto"}</DialogTitle>
            <DialogDescription className="text-slate-400">
              {editingProject ? "Altere o nome do seu projeto de rundown." : "Dê um nome ao seu novo projeto de rundown."}
            </DialogDescription>
          </DialogHeader>
          <motion.div 
            initial={{ opacity: 0, y:10 }}
            animate={{ opacity: 1, y:0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
            className="py-4"
          >
            <Label htmlFor="projectName" className="text-slate-300">Nome do Projeto</Label>
            <Input
              id="projectName"
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              placeholder="Ex: Evento de Lançamento Q3"
              className="mt-1 bg-slate-700 border-slate-600 text-white placeholder-slate-500 focus:ring-sky-500"
              disabled={isSubmittingProject}
            />
          </motion.div>
          <DialogFooter>
            <DialogClose asChild>
              <Button type="button" variant="secondary" className="bg-slate-700 hover:bg-slate-600 text-slate-300" disabled={isSubmittingProject}>Cancelar</Button>
            </DialogClose>
            <Button onClick={handleCreateOrEditProject} className="bg-sky-500 hover:bg-sky-600 text-white flex items-center justify-center" disabled={isSubmittingProject}>
              {isSubmittingProject && <Loader2 className="w-4 h-4 animate-spin mr-2" />}
              {editingProject ? (isSubmittingProject ? "Salvando..." : "Salvar Alterações") : (isSubmittingProject ? "Criando..." : "Criar Projeto")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
};

const WrappedDashboardPage = () => (
  <MainLayout>
    <DashboardPageContent />
  </MainLayout>
);

export default WrappedDashboardPage;
