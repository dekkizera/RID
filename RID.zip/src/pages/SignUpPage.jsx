import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tv, AlertCircle, Loader2, UserPlus } from 'lucide-react';
import { motion } from 'framer-motion';
import { useToast } from '@/components/ui/use-toast';

const SignUpPage = () => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const { signUp, setLoading } = useAuth();
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('As senhas não coincidem.');
      toast({ title: "Erro de Cadastro", description: "As senhas não coincidem.", variant: "destructive" });
      return;
    }
    if (password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres.');
      toast({ title: "Erro de Cadastro", description: "A senha deve ter pelo menos 6 caracteres.", variant: "destructive" });
      return;
    }

    setIsSubmitting(true);
    setLoading(true);
    try {
      const { data, error: signUpError } = await signUp(email, password, fullName);
      if (signUpError) {
        throw signUpError;
      }
      
      toast({ 
        title: "Cadastro realizado com sucesso!", 
        description: "Você será redirecionado para o login. Verifique seu email para confirmação, se aplicável.", 
        duration: 5000 
      });
      
      // Supabase handles email confirmation. If it's on, user needs to confirm.
      // If "Confirm email" is disabled in Supabase Auth settings, user is active immediately.
      // We navigate to login, user can then login.
      navigate('/login');

    } catch (err) {
      console.error("Sign up page error:", err);
      let errorMessage = 'Falha ao criar conta.';
      if (err.message) {
        if (err.message.toLowerCase().includes('user already registered')) {
          errorMessage = 'Este email já está cadastrado. Tente fazer login.';
        } else if (err.message.toLowerCase().includes('rate limit exceeded')) {
          errorMessage = 'Muitas tentativas de cadastro. Tente novamente mais tarde.';
        } else if (err.message.toLowerCase().includes('password should be at least 6 characters')) {
          errorMessage = 'A senha deve ter pelo menos 6 caracteres.';
        }
         else {
          errorMessage = `Erro: ${err.message}`;
        }
      }
      setError(errorMessage);
      toast({ title: "Erro de Cadastro", description: errorMessage, variant: "destructive" });
    } finally {
      setIsSubmitting(false);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-900 flex flex-col items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="flex items-center gap-3 mb-10 text-white"
      >
        <UserPlus className="w-12 h-12 text-green-400" />
        <h1 className="text-5xl font-bold tracking-tight">
          Criar Conta <span className="text-green-400">(RID)</span>
        </h1>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, delay: 0.2, ease: "easeOut" }}
      >
        <Card className="w-full max-w-md bg-slate-800/70 border-slate-700 shadow-2xl backdrop-blur-md">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-white">Cadastre-se</CardTitle>
            <CardDescription className="text-slate-400 pt-1">Crie sua conta para começar a usar o RID.</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="fullName" className="text-slate-300">Nome Completo</Label>
                <Input
                  id="fullName"
                  type="text"
                  placeholder="Seu Nome Completo"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-500 focus:ring-green-500"
                  disabled={isSubmitting}
                />
              </div>
              <div>
                <Label htmlFor="email" className="text-slate-300">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seuemail@exemplo.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-500 focus:ring-green-500"
                  disabled={isSubmitting}
                />
              </div>
              <div>
                <Label htmlFor="password" className="text-slate-300">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Crie uma senha (mín. 6 caracteres)"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-500 focus:ring-green-500"
                  disabled={isSubmitting}
                />
              </div>
              <div>
                <Label htmlFor="confirmPassword" className="text-slate-300">Confirmar Senha</Label>
                <Input
                  id="confirmPassword"
                  type="password"
                  placeholder="Confirme sua senha"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-500 focus:ring-green-500"
                  disabled={isSubmitting}
                />
              </div>
              {error && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="flex items-center p-3 bg-red-500/20 border border-red-500/50 text-red-300 rounded-md text-sm"
                >
                  <AlertCircle className="w-5 h-5 mr-2 flex-shrink-0" />
                  {error}
                </motion.div>
              )}
              <Button 
                type="submit" 
                className="w-full bg-green-500 hover:bg-green-600 text-white text-lg py-6 transition-all duration-300 ease-in-out transform hover:scale-105 flex items-center justify-center"
                disabled={isSubmitting}
              >
                {isSubmitting ? <Loader2 className="w-6 h-6 animate-spin mr-2" /> : null}
                {isSubmitting ? 'Criando Conta...' : 'Criar Conta'}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="flex flex-col items-center space-y-2 pt-4">
            <p className="text-xs text-slate-500">
              Já tem uma conta?{' '}
              <Link to="/login" className="font-medium text-green-400 hover:text-green-300 hover:underline">
                Faça Login
              </Link>
            </p>
          </CardFooter>
        </Card>
      </motion.div>
       <motion.p 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.5 }}
        className="mt-12 text-center text-sm text-slate-500"
      >
        Plataforma de gerenciamento de rundown profissional.
        <br />© {new Date().getFullYear()} Run It Down (RID). Todos os direitos reservados.
      </motion.p>
    </div>
  );
};

export default SignUpPage;