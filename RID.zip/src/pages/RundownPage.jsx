import React from 'react';
import Header from '@/components/Header';
import Rundown from '@/components/Rundown';

const RundownPage = () => {
  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto px-4 py-8">
        <Rundown />
      </main>
    </div>
  );
};

export default RundownPage;