import React, { useState, useEffect } from 'react';

const LiveClock = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timerId = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(timerId);
  }, []);

  return (
    <div className="text-2xl font-mono font-bold text-foreground tracking-wider">
      {time.toLocaleTimeString('pt-BR')}
    </div>
  );
};

export default LiveClock;