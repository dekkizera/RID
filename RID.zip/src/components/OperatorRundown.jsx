
import React, { useState, useCallback, useEffect } from 'react';
import { Play, Pause, RotateCcw, PlusCircle, SkipForward, FolderPlus, Edit3, Trash2, Folder as FolderIcon, AlertTriangle, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import RundownItem from '@/components/RundownItem';
import { useToast } from '@/components/ui/use-toast';
import { useRundownState } from '@/hooks/useRundownState';
import EventForm from '@/components/EventForm';
import FolderForm from '@/components/FolderForm';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { AnimatePresence, motion } from 'framer-motion';

const OperatorRundown = () => {
  const { 
    state, 
    isLoading: isLoadingRundown,
    playPause, 
    resetRundown, 
    selectItem, 
    skipForward, 
    saveEvent, 
    deleteEvent,
    saveFolder,
    deleteFolder,
    defaultColors,
  } = useRundownState();
  const { toast } = useToast();
  
  const rundown = state?.rundown;
  const currentFolderIndex = state?.currentFolderIndex || 0;
  const currentItemIndex = state?.currentItemIndex || 0;
  const isRunning = state?.isRunning || false;
  const elapsedTime = state?.elapsedTime || 0;

  const [isEventFormOpen, setIsEventFormOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);
  const [targetFolderIdForNewEvent, setTargetFolderIdForNewEvent] = useState(null);

  const [isFolderFormOpen, setIsFolderFormOpen] = useState(false);
  const [editingFolder, setEditingFolder] = useState(null);

  const formatTime = (seconds, showSign = false) => {
    const isNegative = seconds < 0;
    if (isNaN(seconds) || typeof seconds !== 'number') seconds = 0;
    
    const absoluteSeconds = Math.abs(Math.round(seconds));
    const h = Math.floor(absoluteSeconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((absoluteSeconds % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(absoluteSeconds % 60).toString().padStart(2, '0');
    
    let sign = '';
    if (showSign) {
      sign = isNegative ? '+' : '';
    }

    return `${sign}${h}:${m}:${s}`;
  };

  const handlePlayPause = () => {
    if (rundown && rundown.folders && rundown.folders.some(f => f.events && f.events.length > 0)) {
      playPause();
    } else {
      toast({ title: 'Rundown Vazio', description: 'Adicione eventos ao rundown para iniciar.', variant: "destructive", duration: 3000 });
    }
  };

  const handleReset = () => {
    resetRundown();
    toast({ title: 'Rundown Reiniciado', description: 'O roteiro voltou ao início.', duration: 3000 });
  };

  const handleItemClick = (folderIndex, itemIndex) => {
    selectItem(folderIndex, itemIndex);
  };
  
  const handleSkipForward = () => {
    if (!rundown || !rundown.folders || !rundown.folders.some(f => f.events && f.events.length > 0)) {
      toast({ title: 'Rundown Vazio', description: 'Não há itens para pular.', variant: "destructive", duration: 3000 });
      return;
    }
    const currentFolder = rundown.folders[currentFolderIndex];
    if (!currentFolder || !currentFolder.events || (currentFolderIndex >= rundown.folders.length -1 && currentItemIndex >= (currentFolder.events.length || 0) - 1) ) {
      toast({ title: 'Fim do Rundown', description: 'Este é o último item.', duration: 3000 });
      return;
    }
    skipForward();
  };

  const handleSaveEventSubmit = (eventData) => {
    const isEditingEvent = !!editingEvent;
    let folderIdToSaveIn;

    if (isEditingEvent) {
      const parentFolder = rundown.folders.find(f => f.events && f.events.some(e => e.id === editingEvent.id));
      folderIdToSaveIn = parentFolder ? parentFolder.id : null;
      if (!folderIdToSaveIn) {
        toast({ title: 'Erro', description: 'Não foi possível encontrar a pasta do evento para edição.', variant: "destructive", duration: 3000 });
        return;
      }
    } else {
      folderIdToSaveIn = targetFolderIdForNewEvent;
      if (!folderIdToSaveIn) {
        if(rundown.folders && rundown.folders.length > 0) {
          folderIdToSaveIn = rundown.folders[0].id; 
        } else {
          toast({ title: 'Erro', description: 'Nenhuma pasta disponível para o novo evento. Crie uma pasta primeiro.', variant: "destructive", duration: 3000 });
          return;
        }
      }
    }
    
    saveEvent(eventData, folderIdToSaveIn, isEditingEvent ? editingEvent.id : null);
    toast({ title: isEditingEvent ? 'Evento Atualizado!' : 'Evento Adicionado!', description: `"${eventData.title}" foi salvo com sucesso.`, duration: 3000 });
    setEditingEvent(null);
    setIsEventFormOpen(false);
    setTargetFolderIdForNewEvent(null);
  };

  const handleEditEvent = (event, folderId) => {
    setEditingEvent(event);
    setIsEventFormOpen(true);
  };

  const handleAddNewEvent = (folderId) => {
    setEditingEvent(null);
    setTargetFolderIdForNewEvent(folderId);
    setIsEventFormOpen(true);
  };
  
  const handleTargetFolderChangeForEventForm = (folderId) => {
    if (!editingEvent) { 
        setTargetFolderIdForNewEvent(folderId);
    }
  };

  const handleDeleteEventAction = (folderId, eventId, eventTitle) => {
    deleteEvent(folderId, eventId);
    toast({ title: 'Evento Removido!', description: `O evento "${eventTitle}" foi removido com sucesso.`, variant: "destructive", duration: 3000 });
  };

  const handleSaveFolderSubmit = (folderData) => {
    saveFolder(folderData, editingFolder ? editingFolder.id : null);
    toast({ title: editingFolder ? 'Pasta Atualizada!' : 'Pasta Adicionada!', description: `A pasta "${folderData.title}" foi salva.`, duration: 3000 });
    setEditingFolder(null);
    setIsFolderFormOpen(false);
  };

  const handleEditFolder = (folder) => {
    setEditingFolder(folder);
    setIsFolderFormOpen(true);
  };

  const handleAddNewFolder = () => {
    setEditingFolder(null);
    setIsFolderFormOpen(true);
  };

  const handleDeleteFolderAction = (folderId, folderTitle) => {
    deleteFolder(folderId);
    toast({ title: 'Pasta Removida!', description: `A pasta "${folderTitle}" e todos os seus eventos foram removidos.`, variant: "destructive", duration: 3000 });
  };
  
  if (isLoadingRundown || !rundown || !rundown.folders || !Array.isArray(rundown.folders)) {
    return (
      <div className="w-full flex flex-col justify-center items-center h-[calc(100vh-200px)]">
        <Loader2 className="w-16 h-16 animate-spin text-sky-400 mb-4" />
        <p className="text-2xl text-muted-foreground">Carregando dados do rundown...</p>
      </div>
    );
  }
  
  const hasEvents = rundown.folders.some(f => f.events && f.events.length > 0);

  return (
    <div className="w-full">
      <EventForm 
        open={isEventFormOpen} 
        onOpenChange={setIsEventFormOpen} 
        onSave={handleSaveEventSubmit} 
        event={editingEvent}
        folders={rundown.folders}
        targetFolderId={targetFolderIdForNewEvent}
        onTargetFolderIdChange={handleTargetFolderChangeForEventForm}
      />
      <FolderForm 
        open={isFolderFormOpen} 
        onOpenChange={setIsFolderFormOpen} 
        onSave={handleSaveFolderSubmit} 
        folder={editingFolder}
        defaultColors={defaultColors}
      />

      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
        className="bg-slate-800/60 backdrop-blur-sm p-6 rounded-xl shadow-2xl mb-8 border border-slate-700"
      >
        <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
          <div>
            <h2 className="text-3xl font-bold text-sky-400">{rundown.title || "Meu Rundown"}</h2>
            <p className="text-slate-400">{rundown.eventDate || new Date().toLocaleDateString()}</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Button onClick={handlePlayPause} size="lg" className="w-full sm:w-32 bg-green-500 hover:bg-green-600 text-white shadow-md hover:shadow-lg transition-all" disabled={!hasEvents}>
              {isRunning ? <><Pause className="mr-2 h-5 w-5" /> Pausar</> : <><Play className="mr-2 h-5 w-5" /> Iniciar</>}
            </Button>
             <Button onClick={handleSkipForward} variant="outline" size="lg" className="w-full sm:w-auto border-slate-600 hover:bg-slate-700/50 shadow-sm hover:shadow-md transition-all"
              disabled={!hasEvents || (currentFolderIndex >= rundown.folders.length -1 && currentItemIndex >= (rundown.folders[currentFolderIndex]?.events?.length || 0) - 1)}
             >
              <SkipForward className="mr-2 h-5 w-5" /> Pular
            </Button>
            <Button onClick={handleReset} variant="outline" size="lg" className="w-full sm:w-auto border-slate-600 hover:bg-slate-700/50 shadow-sm hover:shadow-md transition-all" disabled={!hasEvents}>
              <RotateCcw className="mr-2 h-5 w-5" /> Reiniciar
            </Button>
          </div>
        </div>
      </motion.div>
      <div className="flex justify-end mb-6">
        <Button onClick={handleAddNewFolder} className="bg-sky-500 hover:bg-sky-600 text-white shadow-md hover:shadow-lg transition-all">
          <FolderPlus className="mr-2 h-4 w-4" /> Adicionar Pasta
        </Button>
      </div>
      <div className="space-y-6">
        <AnimatePresence>
        {rundown.folders.length > 0 ? rundown.folders.map((folder, folderIdx) => (
          <motion.div 
            key={folder.id}
            layout
            initial={{ opacity: 0, y: 20, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.98 }}
            transition={{ duration: 0.3, ease: "circOut" }}
            className="bg-slate-800/40 p-4 rounded-lg border backdrop-blur-sm"
            style={{borderColor: folder.color || 'var(--border)'}}
          >
            <div className="flex justify-between items-center mb-4">
              <div className="flex items-center gap-3">
                <FolderIcon className="w-7 h-7 flex-shrink-0" style={{color: folder.color || 'currentColor'}} />
                <h3 className="text-xl font-semibold truncate" style={{color: folder.color || 'currentColor'}} title={folder.title}>{folder.title}</h3>
              </div>
              <div className="flex items-center gap-1">
                <Button variant="outline" size="sm" onClick={() => handleAddNewEvent(folder.id)} className="border-slate-600 hover:bg-slate-700/50">
                  <PlusCircle className="mr-1 h-3.5 w-3.5" /> Evento
                </Button>
                <Button variant="ghost" size="iconSm" onClick={() => handleEditFolder(folder)} className="hover:bg-slate-700/50">
                  <Edit3 className="w-4 h-4" />
                </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="iconSm" className="text-red-500 hover:text-red-400 hover:bg-red-500/10">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-slate-800 border-slate-700 text-white">
                    <AlertDialogHeader>
                      <AlertDialogTitle className="text-sky-400 flex items-center gap-2"><AlertTriangle className="text-yellow-400"/>Você tem certeza?</AlertDialogTitle>
                      <AlertDialogDescription className="text-slate-400">
                        Essa ação não pode ser desfeita. Isso irá remover permanentemente a pasta "{folder.title}" e TODOS os eventos dentro dela.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="bg-slate-700 hover:bg-slate-600 text-slate-300 border-slate-600">Cancelar</AlertDialogCancel>
                      <AlertDialogAction onClick={() => handleDeleteFolderAction(folder.id, folder.title)} className="bg-red-600 hover:bg-red-700 text-white">Deletar Pasta</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </div>
            {folder.events && folder.events.length > 0 ? (
              <motion.div 
                className="space-y-2"
                variants={{ container: { transition: { staggerChildren: 0.05 }}}}
                initial="container"
                animate="container"
              >
                {folder.events.map((item, itemIdx) => (
                  <RundownItem
                    key={item.id}
                    item={item}
                    isActive={folderIdx === currentFolderIndex && itemIdx === currentItemIndex}
                    isRunning={isRunning && folderIdx === currentFolderIndex && itemIdx === currentItemIndex}
                    elapsedTime={folderIdx === currentFolderIndex && itemIdx === currentItemIndex ? elapsedTime : 0}
                    onClick={() => handleItemClick(folderIdx, itemIdx)}
                    formatTime={formatTime}
                    onEdit={() => handleEditEvent(item, folder.id)}
                    onDelete={() => handleDeleteEventAction(folder.id, item.id, item.title)}
                    isOperator={true}
                    folderColor={folder.color}
                    isRundownRunning={isRunning} 
                  />
                ))}
              </motion.div>
            ) : (
              <p className="text-sm text-muted-foreground text-center py-3">Nenhum evento nesta pasta. Clique em "+ Evento" para adicionar.</p>
            )}
          </motion.div>
        )) : (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-16 text-muted-foreground"
          >
            <FolderPlus className="w-20 h-20 mx-auto text-slate-600 mb-4" />
            <p className="text-xl mb-2">Seu rundown está vazio.</p>
            <p>Clique em "Adicionar Pasta" para começar a organizar seus eventos.</p>
          </motion.div>
        )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default OperatorRundown;
