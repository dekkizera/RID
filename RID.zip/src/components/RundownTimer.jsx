import React, { useState, useEffect, useMemo } from 'react';
import { useRundownState } from '@/hooks/useRundownState';
import { Clock } from 'lucide-react';

const RundownTimer = () => {
  const { state } = useRundownState();
  
  const { rundown, currentItemIndex, currentFolderIndex, elapsedTime, isRunning } = state;

  const [totalElapsedDisplay, setTotalElapsedDisplay] = useState(0);

  useEffect(() => {
    if (!rundown || !rundown.folders || !Array.isArray(rundown.folders)) {
      setTotalElapsedDisplay(0);
      return;
    }

    let precedingItemsDuration = 0;
    for (let fIdx = 0; fIdx < rundown.folders.length; fIdx++) {
      const folder = rundown.folders[fIdx];
      if (!folder || !folder.events || !Array.isArray(folder.events)) continue;

      if (fIdx < currentFolderIndex) {
        precedingItemsDuration += folder.events.reduce((acc, item) => acc + (item.duration || 0), 0);
      } else if (fIdx === currentFolderIndex) {
        precedingItemsDuration += folder.events
          .slice(0, currentItemIndex)
          .reduce((acc, item) => acc + (item.duration || 0), 0);
        break; 
      }
    }
    setTotalElapsedDisplay(precedingItemsDuration + (elapsedTime || 0));

  }, [currentFolderIndex, currentItemIndex, elapsedTime, rundown, isRunning]);


  const totalDuration = useMemo(() => {
    return (rundown && rundown.folders && Array.isArray(rundown.folders))
      ? rundown.folders.reduce((folderAcc, folder) => {
          if (!folder || !folder.events || !Array.isArray(folder.events)) return folderAcc;
          return folderAcc + folder.events.reduce((eventAcc, item) => eventAcc + (item.duration || 0), 0);
        }, 0)
      : 0;
  }, [rundown]);

  const formatTime = (seconds) => {
    if (isNaN(seconds) || seconds < 0) seconds = 0;
    const roundedSeconds = Math.round(seconds);
    const h = Math.floor(roundedSeconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((roundedSeconds % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(roundedSeconds % 60).toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
  };

  if (!rundown || !rundown.folders || !Array.isArray(rundown.folders) || !state) {
    return (
      <div className="bg-secondary px-4 py-2 rounded-full flex items-center gap-4 shadow-inner">
        <Clock className="w-6 h-6 text-muted-foreground" />
        <div className="text-lg font-mono font-bold text-foreground tracking-wider">
          <span className="text-muted-foreground">CARREGANDO...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-secondary px-4 py-2 rounded-full flex items-center gap-4 shadow-inner">
      <Clock className={`w-6 h-6 ${isRunning ? 'text-green-400 animate-pulse' : 'text-muted-foreground'}`} />
      <div className="text-lg font-mono font-bold text-foreground tracking-wider">
        <span className="text-muted-foreground">TEMPO:</span> {formatTime(totalElapsedDisplay)}
        <span className="text-muted-foreground mx-2">/</span>
        {formatTime(totalDuration)}
      </div>
    </div>
  );
};

export default RundownTimer;