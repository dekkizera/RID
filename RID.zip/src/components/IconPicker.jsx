import React, { useState, useCallback } from 'react';
import * as LucideIcons from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { UploadCloud, Search } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { cn } from '@/lib/utils';
import { defaultEventIcons } from '@/lib/constants';

const IconPicker = ({ selectedIcon, onIconSelect, iconList }) => {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');

  const handleIconClick = (iconName) => {
    onIconSelect({ type: 'lucide', value: iconName });
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (file.type.startsWith('image/svg') || file.type.startsWith('image/png')) {
        const reader = new FileReader();
        reader.onloadend = () => {
          onIconSelect({ type: 'url', value: reader.result, name: file.name });
          toast({ title: 'Ícone Carregado!', description: `${file.name} foi carregado com sucesso.` });
        };
        reader.readAsDataURL(file);
      } else {
        toast({
          title: 'Formato Inválido',
          description: 'Por favor, use arquivos SVG ou PNG.',
          variant: 'destructive',
        });
      }
    }
  };
  
  const actualIconList = iconList && iconList.length > 0 ? iconList : Object.values(defaultEventIcons).filter((value, index, self) => self.indexOf(value) === index);


  const filteredIcons = actualIconList.filter(iconName =>
    iconName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderIcon = (iconName, customClassName = "w-8 h-8") => {
    const IconComponent = LucideIcons[iconName];
    return IconComponent ? <IconComponent className={customClassName} /> : <LucideIcons.FileText className={customClassName} />;
  };
  
  let currentIconDisplay;
  if (selectedIcon?.type === 'lucide' && selectedIcon.value) {
      currentIconDisplay = renderIcon(selectedIcon.value, "w-10 h-10 text-primary");
  } else if (selectedIcon?.type === 'url' && selectedIcon.value) {
      currentIconDisplay = <img-replace src={selectedIcon.value} alt={selectedIcon.name || "Ícone customizado"} className="w-10 h-10 object-contain" />;
  } else {
      currentIconDisplay = <LucideIcons.FileText className="w-10 h-10 text-muted-foreground" />;
  }


  return (
    <div className="flex flex-col gap-4">
       <div className="flex items-center gap-2 p-2 border rounded-md">
         <span className="text-sm font-medium">Ícone Atual:</span>
         {currentIconDisplay}
         <span className="text-xs text-muted-foreground truncate max-w-[150px]">
           {selectedIcon?.type === 'url' ? selectedIcon.name : selectedIcon?.value}
         </span>
       </div>
      <Tabs defaultValue="library">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="library">Biblioteca de Ícones</TabsTrigger>
          <TabsTrigger value="upload">Upload (SVG/PNG)</TabsTrigger>
        </TabsList>
        <TabsContent value="library">
          <div className="relative my-2">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Buscar ícones..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 w-full"
            />
          </div>
          <ScrollArea className="h-[200px] border rounded-md">
            <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-8 gap-2 p-4">
              {filteredIcons.map(iconName => (
                <Button
                  key={iconName}
                  variant="outline"
                  size="icon"
                  onClick={() => handleIconClick(iconName)}
                  className={cn(
                    "flex justify-center items-center aspect-square h-auto w-full p-2",
                    selectedIcon?.type === 'lucide' && selectedIcon.value === iconName && "ring-2 ring-primary"
                  )}
                  title={iconName}
                >
                  {renderIcon(iconName)}
                </Button>
              ))}
            </div>
            {filteredIcons.length === 0 && (
              <p className="text-center text-muted-foreground py-4">Nenhum ícone encontrado.</p>
            )}
          </ScrollArea>
        </TabsContent>
        <TabsContent value="upload">
          <div className="flex flex-col items-center justify-center gap-3 p-4 border-2 border-dashed rounded-md h-[200px]">
            <UploadCloud className="w-12 h-12 text-muted-foreground" />
            <p className="text-sm text-muted-foreground text-center">
              Arraste e solte um arquivo SVG/PNG aqui, ou clique para selecionar.
            </p>
            <Input
              id="icon-upload"
              type="file"
              className="sr-only"
              accept=".svg,.png"
              onChange={handleFileUpload}
            />
            <Button asChild variant="outline">
              <label htmlFor="icon-upload">Selecionar Arquivo</label>
            </Button>
            <p className="text-xs text-muted-foreground mt-1">Máx. 500KB. SVG recomendado.</p>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default IconPicker;