
import React, { useState, useEffect } from 'react';
import { Link, useLocation, useParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Copy, ExternalLink, Home, Settings, Tv, Loader2 } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/AuthContext';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';


const Header = () => {
  const location = useLocation();
  const { projectId } = useParams();
  const { toast } = useToast();
  const { user, isProjectSessionActive: checkSessionActiveCallback } = useAuth(); // Renamed for clarity
  const [projectDisplayName, setProjectDisplayName] = useState("");
  const [isSessionActiveForHeader, setIsSessionActiveForHeader] = useState(false);
  const [isLoadingSessionStatus, setIsLoadingSessionStatus] = useState(false);

  const isOperatorPage = location.pathname.includes('/operator');
  const isPresenterPage = location.pathname.includes('/presenter');
  const isDashboard = location.pathname === '/';
  const isCommunityPage = location.pathname === '/community';

  let pageTitle = "Run It Down (RID)";

  useEffect(() => {
    const fetchProjectName = async () => {
      if (projectId && supabase && user) {
        try {
          const { data, error } = await supabase
            .from('projects')
            .select('name')
            .eq('id', projectId)
            .eq('user_id', user.id)
            .single();
          if (error && error.code !== 'PGRST116') throw error;
          if (data) {
            setProjectDisplayName(data.name);
          } else {
            setProjectDisplayName("Projeto Desconhecido");
          }
        } catch (err) {
          console.error("Error fetching project name for header:", err);
          setProjectDisplayName("Erro no Projeto");
        }
      } else {
        setProjectDisplayName("");
      }
    };
    fetchProjectName();
  }, [projectId, user]);

  useEffect(() => {
    const updateSessionStatus = async () => {
      if (projectId && isOperatorPage) { // Only check for operator page in header for button states
        setIsLoadingSessionStatus(true);
        const isActive = await checkSessionActiveCallback(projectId);
        setIsSessionActiveForHeader(isActive);
        setIsLoadingSessionStatus(false);
      } else {
        setIsSessionActiveForHeader(false); // Default to false if not on operator page or no projectID
      }
    };
    updateSessionStatus();
    // Optionally, set up a listener or interval if this needs to be more dynamic in the header itself
    // For now, it updates on projectId or page change.
  }, [projectId, isOperatorPage, checkSessionActiveCallback, location.pathname]);


  if (isOperatorPage && projectDisplayName) pageTitle = `${projectDisplayName} - Operador`;
  if (isPresenterPage && projectDisplayName) pageTitle = `${projectDisplayName} - Apresentador`;
  if (isDashboard) pageTitle = "Meus Projetos";
  if (isCommunityPage) pageTitle = "Comunidade";


  const handleCopyPresenterLink = () => {
    if (!projectId) {
      toast({ title: "Erro", description: "ID do projeto não encontrado.", variant: "destructive" });
      return;
    }
    if (!isSessionActiveForHeader && isOperatorPage) {
      toast({ title: "Operação Inativa", description: "Este rundown não está sendo operado no momento. Inicie a operação para ativar o link.", variant: "default", duration: 3000 });
      return;
    }
    const presenterUrl = `${window.location.origin}/project/${projectId}/presenter`;
    navigator.clipboard.writeText(presenterUrl)
      .then(() => {
        toast({ title: "Link Copiado!", description: "Link do apresentador copiado para a área de transferência.", duration: 3000 });
      })
      .catch(err => {
        toast({ title: "Erro ao Copiar", description: "Não foi possível copiar o link.", variant: "destructive", duration: 3000 });
        console.error('Failed to copy: ', err);
      });
  };
  
  const handleViewPresenter = () => {
    if (!projectId) {
      toast({ title: "Erro", description: "ID do projeto não encontrado.", variant: "destructive" });
      return;
    }
    if (!isSessionActiveForHeader && isOperatorPage) {
      toast({ title: "Operação Inativa", description: "Este rundown não está sendo operado no momento. Inicie a operação para visualizar.", variant: "default", duration: 3000 });
      return;
    }
    const presenterUrl = `${window.location.origin}/project/${projectId}/presenter`;
    window.open(presenterUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <motion.header 
      initial={{ y: -60, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ type: "spring", stiffness: 120, damping: 20, delay: 0.1 }}
      className="bg-slate-800/50 backdrop-blur-md shadow-lg sticky top-0 z-50 border-b border-slate-700/50"
    >
      <div className="container mx-auto px-4 sm:px-6 py-3 flex justify-between items-center">
        <div className="flex items-center gap-2">
          {(isOperatorPage || isPresenterPage) && !isDashboard && (
             <Link to="/" className="hidden sm:block">
              <Button variant="ghost" size="sm" className="text-slate-400 hover:text-sky-400 hover:bg-slate-700/50">
                <Home className="w-4 h-4 mr-1.5" />
                Dashboard
              </Button>
            </Link>
          )}
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="RID Logo" className="w-8 h-8 rounded-md object-cover hidden sm:block" />
            <h1 className="text-lg sm:text-xl font-semibold text-sky-400 truncate max-w-[150px] sm:max-w-xs md:max-w-sm lg:max-w-md" title={pageTitle}>
              {pageTitle}
            </h1>
          </div>
        </div>

        <div className="flex items-center space-x-2 sm:space-x-3">
          {isOperatorPage && projectId && (
            <>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleViewPresenter}
                disabled={isLoadingSessionStatus || !isSessionActiveForHeader}
                className="border-sky-600 text-sky-400 hover:bg-sky-500/10 hover:text-sky-300 flex items-center gap-1.5 disabled:opacity-60 disabled:cursor-not-allowed disabled:border-slate-700 disabled:text-slate-500"
              >
                {isLoadingSessionStatus ? <Loader2 className="w-4 h-4 animate-spin" /> : <ExternalLink className="w-4 h-4" />}
                <span className="hidden sm:inline">Ver Apres.</span>
              </Button>
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleCopyPresenterLink}
                disabled={isLoadingSessionStatus || !isSessionActiveForHeader}
                className="border-slate-600 text-slate-400 hover:bg-slate-700/50 hover:text-slate-300 flex items-center gap-1.5 disabled:opacity-60 disabled:cursor-not-allowed disabled:border-slate-700 disabled:text-slate-500"
              >
                {isLoadingSessionStatus ? <Loader2 className="w-4 h-4 animate-spin" /> : <Copy className="w-4 h-4" />}
                <span className="hidden sm:inline">Copiar Link</span>
              </Button>
            </>
          )}
        </div>
      </div>
    </motion.header>
  );
};

export default Header;
