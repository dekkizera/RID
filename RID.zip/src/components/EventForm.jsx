
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Folder, Palette } from 'lucide-react';
import IconPicker from '@/components/IconPicker';
import { lucideIconNames, defaultEventIcons, defaultColors } from '@/lib/constants';
import { useRundownState } from '@/hooks/useRundownState';
import { SketchPicker } from 'react-color';

const EventForm = ({ open, onOpenChange, onSave, event, folders, targetFolderId: initialTargetFolderId, onTargetFolderIdChange }) => {
  const { state: rundownGlobalState } = useRundownState(); 

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [duration, setDuration] = useState(300);
  const [selectedIcon, setSelectedIcon] = useState({ type: 'lucide', value: defaultEventIcons.GENERIC });
  const [selectedFolderId, setSelectedFolderId] = useState('');
  const [textColor, setTextColor] = useState('');
  const [backgroundColor, setBackgroundColor] = useState('');
  const [displayTextColorPicker, setDisplayTextColorPicker] = useState(false);
  const [displayBgColorPicker, setDisplayBgColorPicker] = useState(false);
  
  const isEditing = !!event;
  const noFoldersExist = !folders || folders.length === 0;
  
  const fieldsShouldBeDisabled = noFoldersExist;
  const folderSelectorDisabled = noFoldersExist || isEditing;
  const saveButtonDisabled = noFoldersExist || !selectedFolderId;


  useEffect(() => {
    if (open) {
      if (event && folders) { 
        setTitle(event.title);
        setDescription(event.description || ''); 
        setDuration(event.duration);
        setSelectedIcon(event.icon || { type: 'lucide', value: defaultEventIcons.GENERIC });
        setTextColor(event.textColor || '');
        setBackgroundColor(event.backgroundColor || '');
        const parentFolder = folders.find(f => f.events && f.events.some(e => e.id === event.id));
        setSelectedFolderId(parentFolder ? parentFolder.id : (initialTargetFolderId || (folders && folders.length > 0 ? folders[0].id : '')));
      } else {
        setTitle('');
        setDescription('');
        setDuration(300);
        setSelectedIcon({ type: 'lucide', value: defaultEventIcons.GENERIC });
        setTextColor('');
        setBackgroundColor('');
        setSelectedFolderId(initialTargetFolderId || (folders && folders.length > 0 ? folders[0].id : ''));
      }
      setDisplayTextColorPicker(false);
      setDisplayBgColorPicker(false);
    }
  }, [event, open, folders, initialTargetFolderId]);

  useEffect(() => {
    if (onTargetFolderIdChange && selectedFolderId && !isEditing) {
      onTargetFolderIdChange(selectedFolderId);
    }
  }, [selectedFolderId, onTargetFolderIdChange, isEditing]);

  const handleSave = () => {
    if (!selectedFolderId && !noFoldersExist) {
      rundownGlobalState.toast({ title: 'Erro ao Salvar', description: 'Por favor, selecione uma pasta para este evento.', variant: 'destructive' });
      return;
    }
     if (noFoldersExist) {
      rundownGlobalState.toast({ title: 'Erro ao Salvar', description: 'Por favor, crie uma pasta primeiro.', variant: 'destructive' });
      return;
    }
    onSave({
      title,
      description,
      duration: Number(duration),
      icon: selectedIcon,
      textColor: textColor || null, 
      backgroundColor: backgroundColor || null,
    });
    onOpenChange(false);
  };

  const dialogTitle = isEditing ? 'Editar Evento' : 'Adicionar Novo Evento';
  const dialogDescription = isEditing ? 'Faça alterações no evento aqui.' : 'Crie um novo evento para o seu rundown.';
  

  const ColorPickerField = ({ label, color, setColor, displayColorPicker, setDisplayColorPicker, disabled }) => (
    <div className="space-y-2">
      <Label htmlFor={`${label}-color`} className="flex items-center gap-1">
        <Palette className="w-4 h-4" /> {label}
      </Label>
      <div className="flex items-center gap-2">
        <Button
          type="button"
          onClick={() => !disabled && setDisplayColorPicker(!displayColorPicker)}
          className="p-0 border border-input rounded w-9 h-9 min-w-[36px]"
          style={{ backgroundColor: color || 'transparent' }}
          aria-label={`Escolher cor para ${label.toLowerCase()}`}
          disabled={disabled}
        >
          {!color && <span className="text-xs text-muted-foreground">N/A</span>}
        </Button>
        <Input
          id={`${label}-color-hex`}
          value={color || ''}
          onChange={(e) => setColor(e.target.value)}
          className="w-auto flex-grow"
          placeholder="Ex: #RRGGBB ou deixe vazio"
          disabled={disabled}
        />
      </div>
      {displayColorPicker && !disabled ? (
        <div className="mt-2 relative z-50">
           <div className="absolute" style={{ zIndex: 2 }}>
              <div className="fixed inset-0" onClick={() => setDisplayColorPicker(false)}/>
              <SketchPicker 
                color={color || '#ffffff'} 
                onChangeComplete={(selectedColor) => setColor(selectedColor.hex)} 
                presetColors={defaultColors}
              />
           </div>
        </div>
      ) : null}
    </div>
  );
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle>{dialogTitle}</DialogTitle>
          <DialogDescription>{dialogDescription}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-6 py-4"> {/* Increased gap for better spacing */}
          {folders && folders.length > 0 && (
            <div className="space-y-2">
              <Label htmlFor="folder">Pasta</Label>
              <Select 
                value={selectedFolderId} 
                onValueChange={setSelectedFolderId} 
                disabled={folderSelectorDisabled}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecione uma pasta" />
                </SelectTrigger>
                <SelectContent>
                  {folders.map(folder => (
                    <SelectItem key={folder.id} value={folder.id}>
                      <div className="flex items-center">
                        <Folder className="w-4 h-4 mr-2" style={{color: folder.color}} />
                        {folder.title}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
           {noFoldersExist && (
             <p className="text-sm text-center text-muted-foreground">Crie uma pasta antes de adicionar eventos.</p>
           )}

          <div className="space-y-2">
            <Label htmlFor="title">Título</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} disabled={fieldsShouldBeDisabled} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Descrição</Label>
            <Input id="description" value={description} onChange={(e) => setDescription(e.target.value)} disabled={fieldsShouldBeDisabled} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="duration">Duração (s)</Label>
            <Input id="duration" type="number" value={duration} onChange={(e) => setDuration(e.target.value)} disabled={fieldsShouldBeDisabled} />
          </div>
          
          <ColorPickerField 
            label="Cor do Texto"
            color={textColor}
            setColor={setTextColor}
            displayColorPicker={displayTextColorPicker}
            setDisplayColorPicker={setDisplayTextColorPicker}
            disabled={fieldsShouldBeDisabled}
          />
          <ColorPickerField 
            label="Cor de Fundo"
            color={backgroundColor}
            setColor={setBackgroundColor}
            displayColorPicker={displayBgColorPicker}
            setDisplayColorPicker={setDisplayBgColorPicker}
            disabled={fieldsShouldBeDisabled}
          />

          <div className="space-y-2">
             <Label htmlFor="icon">Ícone do Evento</Label>
             <IconPicker
                selectedIcon={selectedIcon}
                onIconSelect={setSelectedIcon}
                iconList={lucideIconNames}
                disabled={fieldsShouldBeDisabled}
             />
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button" variant="secondary">Cancelar</Button>
          </DialogClose>
          <Button onClick={handleSave} disabled={saveButtonDisabled}>
            Salvar
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EventForm;
