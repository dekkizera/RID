import React, { useState, useEffect, useCallback } from 'react';
import { Play, Pause, RotateCcw, List } from 'lucide-react';
import { Button } from '@/components/ui/button';
import RundownItem from '@/components/RundownItem';
import { mockRundown } from '@/data/mockData';
import { useToast } from '@/components/ui/use-toast';

const Rundown = () => {
  const [rundown, setRundown] = useState(mockRundown);
  const [currentItemIndex, setCurrentItemIndex] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [elapsedTime, setElapsedTime] = useState(0);
  const { toast } = useToast();

  const currentItem = rundown.items[currentItemIndex];
  const totalDuration = rundown.items.reduce((acc, item) => acc + item.duration, 0);

  const formatTime = (seconds) => {
    const h = Math.floor(seconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((seconds % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(seconds % 60).toString().padStart(2, '0');
    return `${h}:${m}:${s}`;
  };

  const handleNext = useCallback(() => {
    if (currentItemIndex < rundown.items.length - 1) {
      setCurrentItemIndex(prev => prev + 1);
      setElapsedTime(0);
    } else {
      setIsRunning(false);
      toast({ title: "Rundown Concluído!", description: "Todos os itens foram executados.", duration: 5000 });
    }
  }, [currentItemIndex, rundown.items.length, toast]);

  useEffect(() => {
    let interval;
    if (isRunning && currentItem) {
      interval = setInterval(() => {
        setElapsedTime(prev => {
          const newTime = prev + 1;
          if (newTime >= currentItem.duration) {
            handleNext();
            return 0;
          }
          return newTime;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRunning, currentItem, handleNext]);

  const handlePlayPause = () => setIsRunning(prev => !prev);
  
  const handleReset = () => {
    setIsRunning(false);
    setCurrentItemIndex(0);
    setElapsedTime(0);
    toast({ title: "Rundown Reiniciado", description: "O roteiro voltou ao início.", duration: 3000 });
  };

  const handleItemClick = (index) => {
    setCurrentItemIndex(index);
    setElapsedTime(0);
  };

  const handleAction = () => {
    toast({
      title: '🚧 Funcionalidade não implementada!',
      description: 'Não se preocupe! Você pode solicitar isso no seu próximo prompt! 🚀',
      duration: 3000,
    });
  };

  return (
    <div className="flex gap-8">
      <div className="w-1/3 bg-secondary/50 p-4 rounded-lg shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold flex items-center gap-2"><List /> Rundowns</h2>
          <Button variant="outline" size="sm" onClick={handleAction}>Gerenciar</Button>
        </div>
        <div className="space-y-2">
          <div className="bg-primary/10 p-3 rounded-md border-l-4 border-primary cursor-pointer">
            <h3 className="font-semibold">{rundown.title}</h3>
            <p className="text-sm text-muted-foreground">Duração Total: {formatTime(totalDuration)}</p>
          </div>
        </div>
      </div>
      <div className="w-2/3">
        <div className="bg-secondary/50 p-6 rounded-lg shadow-2xl mb-6">
          <div className="flex justify-between items-start">
            <div>
              <h2 className="text-3xl font-bold text-primary">{rundown.title}</h2>
              <p className="text-muted-foreground">{rundown.eventDate}</p>
            </div>
            <div className="flex items-center gap-2">
              <Button onClick={handlePlayPause} size="lg" className="w-32 bg-green-500 hover:bg-green-600 text-white">
                {isRunning ? <><Pause className="mr-2 h-5 w-5" /> Pausar</> : <><Play className="mr-2 h-5 w-5" /> Iniciar</>}
              </Button>
              <Button onClick={handleReset} variant="outline" size="lg">
                <RotateCcw className="mr-2 h-5 w-5" /> Reiniciar
              </Button>
            </div>
          </div>
        </div>
        <div className="space-y-3">
          {rundown.items.map((item, index) => (
            <RundownItem
              key={item.id}
              item={item}
              isActive={index === currentItemIndex}
              isRunning={isRunning && index === currentItemIndex}
              elapsedTime={elapsedTime}
              onClick={() => handleItemClick(index)}
              formatTime={formatTime}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default Rundown;