
import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { SketchPicker } from 'react-color';

const FolderForm = ({ open, onOpenChange, onSave, folder, defaultColors }) => {
  const [title, setTitle] = useState('');
  const [color, setColor] = useState(defaultColors ? defaultColors[0] : '#FF6B6B');
  const [displayColorPicker, setDisplayColorPicker] = useState(false);

  useEffect(() => {
    if (folder) {
      setTitle(folder.title);
      setColor(folder.color || (defaultColors ? defaultColors[0] : '#FF6B6B'));
    } else {
      setTitle('');
      setColor(defaultColors ? defaultColors[0] : '#FF6B6B');
    }
  }, [folder, open, defaultColors]);

  const handleSave = () => {
    onSave({
      title,
      color,
    });
    onOpenChange(false);
  };

  const handleColorChange = (selectedColor) => {
    setColor(selectedColor.hex);
  };

  const handleColorPickerToggle = () => {
    setDisplayColorPicker(!displayColorPicker);
  };
  
  const handleColorPickerClose = () => {
    setDisplayColorPicker(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>{folder ? 'Editar Pasta' : 'Adicionar Nova Pasta'}</DialogTitle>
          <DialogDescription>
            {folder ? 'Faça alterações na pasta aqui.' : 'Crie uma nova pasta para organizar seus eventos.'}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="title" className="text-right">Título</Label>
            <Input id="title" value={title} onChange={(e) => setTitle(e.target.value)} className="col-span-3" />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="color" className="text-right">Cor</Label>
            <div className="col-span-3 flex items-center gap-2">
              <Button
                type="button"
                onClick={handleColorPickerToggle}
                className="p-2 border border-input rounded"
                style={{ backgroundColor: color, width: '36px', height: '36px' }}
                aria-label="Escolher cor"
              />
              <Input
                id="color-hex"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                className="w-auto flex-grow"
                placeholder="#RRGGBB"
              />
            </div>
            {displayColorPicker ? (
              <div className="col-start-2 col-span-3 mt-2 relative z-50">
                 <div className="absolute" style={{ zIndex: 2 }}>
                    <div className="fixed inset-0" onClick={handleColorPickerClose}/>
                    <SketchPicker color={color} onChangeComplete={handleColorChange} presetColors={defaultColors} />
                 </div>
              </div>
            ) : null}
          </div>
        </div>
        <DialogFooter>
          <DialogClose asChild>
            <Button type="button" variant="secondary">Cancelar</Button>
          </DialogClose>
          <Button onClick={handleSave}>Salvar</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default FolderForm;
