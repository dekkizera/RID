import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import * as LucideIcons from 'lucide-react';
import { Clock, Pencil, Trash2, AlertTriangle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { defaultEventIcons } from '@/lib/constants';

const RenderEventIcon = ({ icon, className = "w-5 h-5", customColor }) => {
  const style = customColor ? { color: customColor } : {};
  if (!icon) {
    const DefaultIcon = LucideIcons[defaultEventIcons.GENERIC] || LucideIcons.FileText;
    return <DefaultIcon className={className} style={style} />;
  }

  if (icon.type === 'lucide') {
    const IconComponent = LucideIcons[icon.value] || LucideIcons[defaultEventIcons.GENERIC] || LucideIcons.FileText;
    return <IconComponent className={className} style={style} />;
  }

  if (icon.type === 'url' && icon.value) {
    return <img-replace src={icon.value} alt={icon.name || 'Ícone personalizado'} className={cn(className, "object-contain")} style={style} />;
  }
  
  const FallbackIcon = LucideIcons[defaultEventIcons.GENERIC] || LucideIcons.FileText;
  return <FallbackIcon className={className} style={style} />;
};


const RundownItem = ({ item, isActive, isRunning, elapsedTime, onClick, formatTime, onEdit, onDelete, isOperator, folderColor }) => {
  const remainingTime = item.duration - (elapsedTime || 0);
  const progress = elapsedTime && item.duration > 0 ? (elapsedTime / item.duration) * 100 : 0;

  const itemBackgroundColor = item.backgroundColor;
  const itemTextColor = item.textColor;

  const getStatusColorClasses = () => {
    if (!isActive) return folderColor ? `border-[${folderColor}]` : 'border-slate-700';
    if (remainingTime < 10 && isRunning && remainingTime >= 0) return 'border-red-500 shadow-red-500/30';
    if (remainingTime < 30 && isRunning && remainingTime >= 0) return 'border-yellow-500 shadow-yellow-500/30';
    if (remainingTime < 0 && isRunning) return 'border-red-700 shadow-red-700/40'; 
    return folderColor ? `border-[${folderColor}] shadow-[${folderColor}]/20` : 'border-green-500 shadow-green-500/20';
  };
  
  const getActiveBgColor = () => {
    if (itemBackgroundColor) return itemBackgroundColor;
    if (folderColor) {
      try {
        let r = parseInt(folderColor.slice(1, 3), 16);
        let g = parseInt(folderColor.slice(3, 5), 16);
        let b = parseInt(folderColor.slice(5, 7), 16);
        return `rgba(${r}, ${g}, ${b}, 0.15)`; // Slightly more opaque
      } catch (e) {
        return 'bg-sky-500/15'; 
      }
    }
    return 'bg-sky-500/15';
  };

  const itemIcon = item.icon || { type: 'lucide', value: defaultEventIcons.GENERIC };

  const dynamicStyles = {
    backgroundColor: isActive ? getActiveBgColor() : (itemBackgroundColor || 'var(--card)'),
    color: itemTextColor || undefined,
  };
  
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 15, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -15, scale: 0.98 }}
      transition={{ duration: 0.25, ease: "circOut" }}
      onClick={onClick}
      className={cn(
        'p-3 rounded-lg shadow-md transition-all duration-300 border-l-4 mb-2 backdrop-blur-sm',
        isActive ? `scale-[1.02] shadow-lg ${getStatusColorClasses()}` : (onClick ? 'hover:bg-slate-700/50 cursor-pointer border-slate-700' : 'border-slate-700'),
        itemBackgroundColor ? '' : 'bg-slate-800/60' // Default bg if no item.backgroundColor
      )}
      style={dynamicStyles}
    >
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 flex-grow min-w-0">
          <div className="flex-shrink-0 w-5 h-5 flex items-center justify-center" style={{ color: itemTextColor || folderColor || 'var(--primary)'}}>
             <RenderEventIcon icon={itemIcon} customColor={itemTextColor || folderColor} />
          </div>
          <div className="flex-grow min-w-0">
            <h3 className="font-semibold text-md truncate" title={item.title} style={{ color: itemTextColor || undefined }}>{item.title}</h3>
            <p className="text-xs truncate" title={item.description} style={{ color: itemTextColor ? `color-mix(in srgb, ${itemTextColor} 70%, var(--muted-foreground))` : 'var(--muted-foreground)' }}>{item.description}</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-right flex-shrink-0 ml-2">
          <div className="flex items-center gap-1 font-mono text-sm" style={{ color: itemTextColor ? `color-mix(in srgb, ${itemTextColor} 80%, var(--muted-foreground))` : 'var(--muted-foreground)' }}>
            <Clock className="w-4 h-4" />
            <span>{formatTime(item.duration, false)}</span>
          </div>
          {isActive && isRunning && (
            <div className={cn("font-mono text-md font-bold", remainingTime < 0 ? "text-red-400" : "text-yellow-400")} style={remainingTime < 0 ? {color: itemTextColor ? `color-mix(in srgb, ${itemTextColor} 100%, #f87171)` : '#f87171'} : {color: itemTextColor ? `color-mix(in srgb, ${itemTextColor} 100%, #facc15)` : '#facc15'} }>
              {formatTime(remainingTime, true)}
            </div>
          )}
          {isOperator && (
            <div className="flex items-center gap-0.5" onClick={(e) => e.stopPropagation()}>
              <Button variant="ghost" size="iconSm" onClick={onEdit} style={{color: itemTextColor || undefined}} className="hover:bg-slate-700/50">
                <Pencil className="w-3.5 h-3.5" />
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="iconSm" className="text-red-500 hover:text-red-400 hover:bg-red-500/10" style={{color: itemTextColor ? `color-mix(in srgb, ${itemTextColor} 100%, #ef4444)` : '#ef4444'}}>
                      <Trash2 className="w-3.5 h-3.5" />
                    </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-slate-800 border-slate-700 text-white">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="text-sky-400 flex items-center gap-2"><AlertTriangle className="text-yellow-400"/>Você tem certeza?</AlertDialogTitle>
                    <AlertDialogDescription className="text-slate-400">
                      Essa ação não pode ser desfeita. Isso irá remover permanentemente o evento "{item.title}" do rundown.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="bg-slate-700 hover:bg-slate-600 text-slate-300 border-slate-600">Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={onDelete} className="bg-red-600 hover:bg-red-700 text-white">Deletar Evento</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          )}
        </div>
      </div>
      {isActive && (
        <div className="mt-2 h-1.5 rounded-full overflow-hidden" style={{backgroundColor: itemTextColor ? `color-mix(in srgb, ${itemTextColor} 10%, var(--primary-foreground))` : 'var(--primary-foreground)'}}>
          <motion.div
            className={cn(
              'h-full rounded-full transition-colors duration-300',
              remainingTime < 0 && isRunning ? 'bg-red-700' :
              remainingTime < 10 && isRunning ? 'bg-red-500' :
              remainingTime < 30 && isRunning ? 'bg-yellow-500' : (folderColor || 'bg-green-500')
            )}
            style={remainingTime >=0 && isRunning ? {backgroundColor: folderColor || '#22c55e'} : {}} // Ensure green has hex
            initial={{ width: '0%' }}
            animate={{ width: `${Math.max(0, Math.min(100, progress))}%` }}
            transition={{ duration: isRunning ? 0.25 : 0.3, ease: isRunning ? 'linear' : 'easeOut' }}
          />
        </div>
      )}
    </motion.div>
  );
};

export default RundownItem;