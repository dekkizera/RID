
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { LogOut, Tv, Users2, FolderGit2, SearchCode, Loader2 } from 'lucide-react'; 
import { motion } from 'framer-motion';

const MainLayout = ({ children }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout, loading: authLoading } = useAuth();

  const navItems = [
    { name: "Meus Projetos", path: "/", icon: <Tv className="w-5 h-5" /> },
    { name: "Comunidade", path: "/community", icon: <Users2 className="w-5 h-5" /> },
  ];
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-indigo-900 text-white flex">
      <aside className="w-64 bg-slate-800/70 backdrop-blur-lg p-6 flex flex-col shadow-2xl border-r border-slate-700/50">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="flex items-center gap-3 mb-10"
        >
          <img  src="/logo.png" alt="Run It Down Logo" className="w-10 h-10 rounded-md object-cover shadow-lg" />
          <h1 className="text-2xl font-bold">
            RID <span className="text-sky-400">Pro</span>
          </h1>
        </motion.div>
        <nav className="flex-grow">
          <motion.ul 
            className="space-y-2"
            variants={{
              hidden: { opacity: 0 },
              show: {
                opacity: 1,
                transition: {
                  staggerChildren: 0.1,
                  delayChildren: 0.2
                }
              }
            }}
            initial="hidden"
            animate="show"
          >
            {navItems.map((item) => (
              <motion.li 
                key={item.name}
                variants={{
                  hidden: { opacity: 0, x: -30 },
                  show: { opacity: 1, x: 0 }
                }}
              >
                <Button
                  variant={location.pathname === item.path ? "secondary" : "ghost"}
                  className={`w-full justify-start text-base py-3 px-4 transition-all duration-200 ease-in-out ${
                    location.pathname === item.path
                      ? "bg-sky-500/20 text-sky-300 shadow-inner shadow-sky-500/30"
                      : "text-slate-400 hover:bg-slate-700/50 hover:text-sky-400 transform hover:translate-x-1"
                  }`}
                  onClick={() => navigate(item.path)}
                >
                  {item.icon}
                  <span className="ml-3">{item.name}</span>
                </Button>
              </motion.li>
            ))}
          </motion.ul>
        </nav>
        <motion.div 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4, ease: "easeOut" }}
          className="mt-auto"
        >
           <div className="text-xs text-slate-500 mb-2 text-center">
              {authLoading ? <Loader2 className="w-4 h-4 animate-spin mx-auto text-slate-400" /> : 
                (user ? `Logado como: ${user.email?.split('@')[0]}` : 'Não autenticado')
              }
           </div>
          <Button onClick={logout} variant="outline" className="w-full border-slate-600 hover:bg-red-500/10 hover:text-red-400 hover:border-red-500/30 text-slate-400 transition-colors flex items-center justify-center" disabled={authLoading}>
            {authLoading ? <Loader2 className="w-5 h-5 animate-spin mr-2" /> : <LogOut className="w-5 h-5 mr-2" />}
            Sair
          </Button>
        </motion.div>
      </aside>

      <div className="flex-1 flex flex-col overflow-hidden">
        <motion.header 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="p-4 sm:p-6 shadow-lg bg-slate-800/30 backdrop-blur-md sticky top-0 z-30 border-b border-slate-700/50"
        >
          <div className="container mx-auto flex justify-between items-center">
            <h1 className="text-xl sm:text-2xl font-semibold text-slate-200">
              {navItems.find(item => item.path === location.pathname)?.name || "Dashboard"}
            </h1>
          </div>
        </motion.header>
        <main className="flex-grow container mx-auto p-4 sm:p-8 overflow-y-auto">
          {children}
        </main>
        <footer className="text-center p-3 text-xs text-slate-600 border-t border-slate-700/50">
          © {new Date().getFullYear()} Run It Down (RID). Plataforma para produções impecáveis.
        </footer>
      </div>
    </div>
  );
};

export default MainLayout;
