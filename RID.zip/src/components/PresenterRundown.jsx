
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useRundownState } from '@/hooks/useRundownState';
import RundownItem from '@/components/RundownItem';
import { cn } from '@/lib/utils';
import * as LucideIcons from 'lucide-react';
import { Loader2, Tv2, ChevronsRight } from 'lucide-react';
import { defaultEventIcons } from '@/lib/constants';


const RenderEventIconPresenter = ({ icon, className = "w-10 h-10", customColor }) => {
  const style = customColor ? { color: customColor } : {};
  if (!icon) {
    const DefaultIcon = LucideIcons[defaultEventIcons.GENERIC] || LucideIcons.FileText;
    return <DefaultIcon className={className} style={style} />;
  }

  if (icon.type === 'lucide') {
    const IconComponent = LucideIcons[icon.value] || LucideIcons[defaultEventIcons.GENERIC] || LucideIcons.FileText;
    return <IconComponent className={className} style={style} />;
  }

  if (icon.type === 'url' && icon.value) {
    return <img src={icon.value} alt={icon.name || 'Ícone personalizado'} className={cn(className, "object-contain")} style={style} />;
  }
  
  const FallbackIcon = LucideIcons[defaultEventIcons.GENERIC] || LucideIcons.FileText;
  return <FallbackIcon className={className} style={style} />;
};

const PresenterRundown = () => {
  const { state, isLoading } = useRundownState();
  
  const rundown = state?.rundown;
  const currentFolderIndex = state?.currentFolderIndex || 0;
  const currentItemIndex = state?.currentItemIndex || 0;
  const isRunning = state?.isRunning || false;
  const elapsedTime = state?.elapsedTime || 0;

  const formatTime = (seconds, showSign = false) => {
    const isNegative = seconds < 0;
    if (isNaN(seconds) || typeof seconds !== 'number') seconds = 0;

    const absoluteSeconds = Math.abs(Math.round(seconds));
    const h = Math.floor(absoluteSeconds / 3600).toString().padStart(2, '0');
    const m = Math.floor((absoluteSeconds % 3600) / 60).toString().padStart(2, '0');
    const s = Math.floor(absoluteSeconds % 60).toString().padStart(2, '0');
    
    let sign = '';
    if (showSign) {
      sign = isNegative ? '+' : ''; 
    }
    return `${sign}${h}:${m}:${s}`;
  };
  
  if (isLoading || !rundown || !rundown.folders || !Array.isArray(rundown.folders)) {
    return (
      <div className="flex flex-col h-[calc(100vh-120px)] gap-8 justify-center items-center text-slate-400">
        <Loader2 className="w-20 h-20 animate-spin text-sky-500" />
        <p className="text-2xl">Carregando rundown...</p>
      </div>
    );
  }

  const currentFolder = rundown.folders[currentFolderIndex];
  const currentItem = currentFolder?.events?.[currentItemIndex];
  
  let nextItem = null;
  let nextItemFolderColor = null;
  if (currentFolder?.events && currentItemIndex < currentFolder.events.length - 1) {
    nextItem = currentFolder.events[currentItemIndex + 1];
    nextItemFolderColor = currentFolder.color;
  } else if (currentFolderIndex < rundown.folders.length - 1) {
    let folderIdx = currentFolderIndex + 1;
    while(folderIdx < rundown.folders.length) {
      const nextFolderCandidate = rundown.folders[folderIdx];
      if (nextFolderCandidate?.events?.length > 0) {
        nextItem = nextFolderCandidate.events[0];
        nextItemFolderColor = nextFolderCandidate.color;
        break;
      }
      folderIdx++;
    }
  }
  
  let displayRemainingTime = 0;
  let isOverrun = false;

  if (currentItem) {
    const actualRemaining = currentItem.duration - elapsedTime;
    displayRemainingTime = actualRemaining; 
    if (actualRemaining < 0) {
      isOverrun = true;
    }
  }
  
  const getStatusBgStyle = () => {
    if (!currentItem) return { backgroundColor: 'rgba(55, 65, 81, 0.8)' }; 
    if (!isRunning) return { backgroundColor: 'rgba(107, 114, 128, 0.8)' }; 
    if (isOverrun) return { backgroundColor: 'rgba(185, 28, 28, 0.9)' }; 
    if (displayRemainingTime < 10 && currentItem.duration > 0 && !isOverrun) return { backgroundColor: 'rgba(220, 38, 38, 0.9)' }; 
    if (displayRemainingTime < 30 && currentItem.duration > 0 && !isOverrun) return { backgroundColor: 'rgba(245, 158, 11, 0.9)' }; 
    return currentFolder?.color ? { backgroundColor: `${currentFolder.color}E6` } : { backgroundColor: 'rgba(34, 197, 94, 0.9)' }; 
  };


  const hasAnyEvents = rundown.folders.some(f => f.events && f.events.length > 0);
  const currentItemIcon = currentItem?.icon || { type: 'lucide', value: defaultEventIcons.GENERIC };
  const currentItemTextColor = currentItem?.textColor || 'text-white'; 
  const currentItemBgColor = currentItem?.backgroundColor; 

  const mainCardStyle = currentItemBgColor ? { backgroundColor: currentItemBgColor } : getStatusBgStyle();
  const mainCardTextColor = currentItemTextColor;


  return (
    <div className="flex flex-col h-[calc(100vh-120px)] gap-6">
      <motion.div 
        className="transition-colors duration-500 text-white rounded-xl shadow-2xl p-6 sm:p-8 flex flex-col justify-center items-center text-center flex-grow backdrop-blur-md border border-slate-700/50"
        style={mainCardStyle}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={currentItem?.id || 'empty-rundown'}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -30 }}
            transition={{ duration: 0.4, ease: "circOut" }}
            className="flex flex-col justify-center items-center w-full"
          >
            <p className="text-xl sm:text-2xl font-semibold mb-2 opacity-80" style={{color: mainCardTextColor}}>AGORA</p>
            <div className="flex justify-center items-center gap-4 mb-4 opacity-90" style={{color: mainCardTextColor}}>
                {currentItem && <RenderEventIconPresenter icon={currentItemIcon} className="w-8 h-8 sm:w-10 sm:h-10" customColor={mainCardTextColor} />}
            </div>
            <h2 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-2 break-words w-full leading-tight" style={{color: mainCardTextColor}}>
              {currentItem?.title || (hasAnyEvents ? 'Aguardando Início' : 'Rundown Vazio')}
            </h2>
            <p className="text-xl sm:text-2xl md:text-3xl opacity-80 break-words w-full" style={{color: mainCardTextColor}}>{currentItem?.description}</p>
            {currentItem && (
              <div className="mt-6 font-mono text-5xl sm:text-7xl md:text-8xl font-bold tracking-tighter" style={{color: mainCardTextColor}}>
                {formatTime(displayRemainingTime, true)}
              </div>
            )}
             {!currentItem && !hasAnyEvents && (
                <div className="mt-6 text-xl sm:text-2xl opacity-70 flex flex-col items-center gap-3" style={{color: mainCardTextColor}}>
                  <Tv2 className="w-16 h-16 opacity-50"/>
                  Adicione pastas e eventos no painel do Operador.
                </div>
            )}
             {currentItem && !isRunning && hasAnyEvents && (
                <p className="mt-6 text-2xl sm:text-3xl font-semibold animate-pulse opacity-90" style={{color: mainCardTextColor}}>PAUSADO</p>
             )}
          </motion.div>
        </AnimatePresence>
      </motion.div>
      
      <motion.div 
        className="bg-slate-800/60 backdrop-blur-sm p-4 sm:p-6 rounded-xl shadow-xl border border-slate-700"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1, ease: "easeOut" }}
      >
        <h3 className="text-xl sm:text-2xl font-bold mb-3 text-sky-400 flex items-center gap-2">
          <ChevronsRight className="w-7 h-7"/> A Seguir
        </h3>
        {nextItem ? (
          <RundownItem 
            item={nextItem} 
            formatTime={(secs) => formatTime(secs, false)}
            isOperator={false}
            elapsedTime={0} 
            isActive={false}
            isRunning={false}
            folderColor={nextItemFolderColor}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-slate-500 py-4">
             <p className="text-md sm:text-lg">{hasAnyEvents && currentItem ? 'Fim do roteiro.' : 'Nenhum evento programado.'}</p>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default PresenterRundown;
