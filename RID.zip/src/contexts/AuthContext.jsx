import React, { createContext, useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { useToast } from '@/components/ui/use-toast';

const AuthContext = createContext(null);

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    setLoading(true);
    if (!supabase) {
      console.error("AuthContext: Supabase client is not initialized. Cannot proceed.");
      toast({
        title: "Erro Crítico de Configuração",
        description: "O cliente Supabase não foi inicializado. A autenticação e funcionalidades de dados não funcionarão. Verifique a conexão com o Supabase.",
        variant: "destructive",
        duration: Infinity, 
      });
      setLoading(false);
      return;
    }

    const getSessionAndUser = async () => {
      try {
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        if (sessionError) {
          console.error("Error getting session:", sessionError.message);
          toast({ title: "Erro de Sessão", description: `Não foi possível obter a sessão: ${sessionError.message}`, variant: "destructive" });
          setUser(null);
        } else {
          setUser(session?.user ?? null);
        }
      } catch (e) {
        console.error("Exception in getSessionAndUser:", e.message);
        toast({ title: "Erro Inesperado na Sessão", description: e.message, variant: "destructive" });
        setUser(null);
      } finally {
        setLoading(false);
      }
    };

    getSessionAndUser();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setLoading(true);
        setUser(session?.user ?? null);
        setLoading(false); 
        if (event === 'SIGNED_OUT') {
          navigate('/login');
        } else if (event === 'SIGNED_IN') {
           // No need to navigate here, ProtectedRoute will handle it or user is already on a protected page.
        } else if (event === 'USER_UPDATED') {
          // Handle user updates if necessary
        }
      }
    );

    return () => {
      authListener?.subscription?.unsubscribe();
    };
  }, [navigate, toast]);

  const login = async (email, password) => {
    if (!supabase) {
      toast({ title: "Erro de Conexão", description: "Supabase não conectado. Login indisponível.", variant: "destructive" });
      throw new Error("Supabase client não inicializado.");
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      setUser(data.user); // Manually set user here for immediate feedback
      return data;
    } catch (error) {
      console.error("Login error in AuthContext:", error);
      throw error; 
    } finally {
      setLoading(false); 
    }
  };

  const signUp = async (email, password, fullName) => {
    if (!supabase) {
      toast({ title: "Erro de Conexão", description: "Supabase não conectado. Cadastro indisponível.", variant: "destructive" });
      throw new Error("Supabase client não inicializado.");
    }
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          }
        }
      });
      if (error) throw error;
      // User state will be updated by onAuthStateChange listener.
      // If email confirmation is required, user object in `data` might be null or have limited info until confirmed.
      toast({ title: "Cadastro Realizado!", description: "Verifique seu email para confirmação, se aplicável.", duration: 5000 });
      return data;
    } catch (error) {
      console.error("SignUp error in AuthContext:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    if (!supabase) {
      toast({ title: "Erro de Conexão", description: "Supabase não conectado. Logout indisponível.", variant: "destructive" });
      throw new Error("Supabase client não inicializado.");
    }
    setLoading(true);
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        toast({ title: "Erro ao Sair", description: error.message, variant: "destructive" });
        throw error;
      }
      setUser(null); 
      navigate('/login');
      toast({ title: "Logout", description: "Você saiu da sua conta.", duration: 3000 });
    } catch (error) {
      console.error("Logout error in AuthContext:", error);
    } finally {
      setLoading(false);
    }
  };
  
  const isProjectSessionActive = async (projectId) => {
    if (!supabase || !user) return false;
    try {
      const { data, error } = await supabase
        .from('rundowns')
        .select('is_running, last_updated_by_operator_at')
        .eq('project_id', projectId)
        .single();

      if (error && error.code !== 'PGRST116') { 
        console.error('Error fetching project session status:', error.message);
        return false;
      }
      if (!data) return false;

      const isActive = data.is_running;
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000).toISOString();
      const isRecent = data.last_updated_by_operator_at > fiveMinutesAgo;
      
      return isActive && isRecent;

    } catch (err) {
      console.error('Exception fetching project session status:', err.message);
      return false;
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, signUp, logout, loading, setLoading, isProjectSessionActive }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};